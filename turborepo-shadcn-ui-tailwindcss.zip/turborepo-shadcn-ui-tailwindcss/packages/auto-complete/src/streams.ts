import { CharStream } from 'antlr4ts';
import { Interval } from 'antlr4ts/misc/Interval';

export class CaseChangingCharStream implements CharStream {
    private stream: CharStream;
    private uppercase: boolean;

    constructor(stream: CharStream, uppercase: boolean = false) {
        this.stream = stream;
        this.uppercase = uppercase;
    }

    get size(): number { return this.stream.size; }
    get index(): number { return this.stream.index; }
    get sourceName(): string { return this.stream.sourceName; }

    getText(interval: Interval): string {
        return this.stream.getText(interval);
    }

    consume(): void {
        return this.stream.consume();
    }

    LA(i: number): number {
        const charCode = this.stream.LA(i);

        if (charCode <= 0) {
            return charCode;
        }

        if (this.uppercase) {
            return String.fromCharCode(charCode).toUpperCase().charCodeAt(0);
        }

        return String.fromCharCode(charCode).toLowerCase().charCodeAt(0);
    }

    mark(): number {
        return this.stream.mark();
    }

    release(marker: number): void {
        return this.stream.release(marker);
    }

    seek(index: number): void {
        return this.stream.seek(index);
    }
}
