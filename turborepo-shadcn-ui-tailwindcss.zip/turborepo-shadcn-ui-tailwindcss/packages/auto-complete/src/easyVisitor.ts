import { EasyParserVisitor } from "./generated/EasyParserVisitor";
import * as parser from "./generated/EasyParser";
import { AbstractParseTreeVisitor } from "antlr4ts/tree/AbstractParseTreeVisitor";
import { ParseTree } from "antlr4ts/tree/ParseTree";

import { ErrorNode } from "antlr4ts/tree/ErrorNode";
import { TerminalNode } from "antlr4ts/tree/TerminalNode";

const AGGR_COL_PREFIX = "aggr_col";

export class ColumnExpr {
  column;
  alias;
  constructor(col: string, alias: string) {
    this.column = col;
    this.alias = alias;
  }

  get_column_expr() {
    return this.alias ? `${this.column} as ${this.alias}` : this.column;
  }

  get_alias() {
    return this.alias ? this.alias : this.column;
  }

  toString() {
    return this.get_column_expr();
  }
}

export class AggrExpr {
  orig_name;
  name;
  is_distinct;
  sql_expr;
  constructor(name: string, is_distinct?: boolean, sql_expr?: string) {
    this.orig_name = name;
    this.name = name.toLowerCase();
    this.is_distinct = is_distinct ? is_distinct : false;
    this.sql_expr = sql_expr;
  }

  can_be_reduced() {
    if (this.is_distinct) {
      return false;
    } else if (this.name === "avg") {
      return false;
    } else {
      return true;
    }
  }

  get_reduce_func_name() {
    if (["count", "sum"].includes(this.name)) {
      return "sum";
    } else {
      return this.name;
    }
  }

  toString() {
    return this.sql_expr;
  }
}

export class AggrFunc {
  column;
  aggr_expr;
  alias;
  constructor(aggr_expr: AggrExpr, alias: string) {
    this.column = aggr_expr.sql_expr;
    this.aggr_expr = aggr_expr;
    this.alias = alias;
  }

  get_aggr_func() {
    return `${this.column} as ${this.alias}`;
  }

  get_reduce_aggr_func() {
    if (this.aggr_expr.can_be_reduced()) {
      const reduce_aggr_expr = this.aggr_expr.get_reduce_func_name();
      return `${reduce_aggr_expr}(${this.alias}) as {this.alias}`;
    } else {
      return null;
    }
  }

  toString() {
    return this.get_aggr_func();
  }
}

export class OrderItem {
  column;
  order_dir;
  constructor(column: string, order_dir?: string) {
    this.column = column;
    this.order_dir = order_dir;
  }

  get_order_clause() {
    return this.order_dir ? `${this.column} ${this.order_dir}` : this.column;
  }

  toString() {
    return this.get_order_clause();
  }
}

export class EasyQLVisitor
  extends AbstractParseTreeVisitor<any>
  implements EasyParserVisitor<any>
{
  columns;
  aliases: string[] = [];
  col_seq = 1;
  aggr_func_dict: Record<string, any> = {};
  alias_2_field_map: Record<string, any> = {};

  constructor(fields: string[]) {
    super();
    this.columns = fields;
  }

  _get_expected_tokens(ctx: parser.EqlContext) {
    const e = ctx.exception;
    let expected_tokens;
    if (e) {
      const recognizer = e.recognizer;
      expected_tokens = e.expectedTokens?.toString();
    }
    return expected_tokens;
  }

  _is_terminal_token(token: ParseTree, target_token_type: number) {
    if (!(token instanceof TerminalNode)) {
      return false;
    }
    return token.symbol.type == target_token_type;
  }

  /**
   * Visit a parse tree produced by `EasyParser.eql`.
   * @param ctx the parse tree
   * @return the visitor result
   */
  visitEql(ctx: parser.EqlContext) {
    const results: any[] = [];
    const count = ctx.childCount;
    for (let i = 0; i < count; i++) {
      if (ctx.getChild(i) instanceof ErrorNode) {
        const msg = `Mismatched input '${ctx.getChild(i).text}' expecting ${this._get_expected_tokens(ctx)} `;
        throw new Error(msg);
      }
      const r = this.visit(ctx.getChild(i));
      if (r) {
        results.push(r);
      }
    }
    return results;
  }

  /**
   * Visit a parse tree produced by `EasyParser.from_item`.
   * @param ctx the parse tree
   * @return the visitor result
   */
  visitFrom_item(ctx: parser.From_itemContext) {
    return { from: this.visitChildren(ctx) };
  }

  /**
   * Visit a parse tree produced by `EasyParser.where_operator`.
   * @param ctx the parse tree
   * @return the visitor result
   */
  visitWhere_operator(ctx: parser.Where_operatorContext) {
    return { where: this.visitChildren(ctx) };
  }

  /**
   * Visit a parse tree produced by `EasyParser.aggr_operator`.
   * @param ctx the parse tree
   * @return the visitor result
   */
  visitAggr_operator(ctx: parser.Aggr_operatorContext) {
    let projected_fields: string[] = [];
    const group_by = [];
    const aggr_func = [];
    for (let i = 0; i < ctx.childCount; i++) {
      if (ctx.getChild(i) instanceof parser.Aggr_funcContext) {
        const func = this.visit(ctx.getChild(i));
        projected_fields.push(func.get_aggr_func());
        aggr_func.push(func);
      } else if (ctx.getChild(i) instanceof parser.Grouping_elementContext) {
        group_by.push(this.visit(ctx.getChild(i)));
      }
      projected_fields = [...group_by, ...projected_fields];
    }
    return {
      projected_fields: projected_fields,
      "group by": group_by,
      aggr_func,
    };
  }

  /**
   * Visit a parse tree produced by `EasyParser.sort_operator`.
   * @param ctx the parse tree
   * @return the visitor result
   */
  visitSort_operator(ctx: parser.Sort_operatorContext) {
    const order_by = [];
    for (let i = 0; i < ctx.childCount; i++) {
      if (ctx.getChild(i) instanceof parser.Order_itemContext) {
        order_by.push(this.visit(ctx.getChild(i)));
      }
    }
    return { "order by": order_by };
  }

  /**
   * Visit a parse tree produced by `EasyParser.fields_operator`.
   * @param ctx the parse tree
   * @return the visitor result
   */
  visitFields_operator(ctx: parser.Fields_operatorContext) {
    const fields = [];
    for (let i = 0; i < ctx.childCount; i++) {
      if (ctx.getChild(i) instanceof parser.ColumnContext) {
        fields.push(this.visit(ctx.getChild(i)));
      }
    }
    return { fields: fields };
  }

  /**
   * Visit a parse tree produced by `EasyParser.limit_operator`.
   * @param ctx the parse tree
   * @return the visitor result
   */
  visitLimit_operator(ctx: parser.Limit_operatorContext) {
    try {
      const limit = this.visitChildren(ctx);
      return { limit: limit };
    } catch (e) {
      throw new Error(`limit expects integer not '${ctx.getChild(1).text}'`);
    }
  }

  /**
   * Visit a parse tree produced by `EasyParser.grouping_element`.
   * @param ctx the parse tree
   * @return the visitor result
   */
  visitGrouping_element(ctx: parser.Grouping_elementContext) {
    return this.visitChildren(ctx);
  }

  /**
   * Visit a parse tree produced by `EasyParser.aggr_func`.
   * @param ctx the parse tree
   * @return the visitor result
   */
  visitAggr_func(ctx: parser.Aggr_funcContext) {
    let col_alias;
    let aggr_expr;
    if (ctx.childCount === 1) {
      aggr_expr = this.visit(ctx.getChild(0));
      col_alias = `${AGGR_COL_PREFIX}${this.col_seq}`;
      this.col_seq += 1;
    } else if (ctx.childCount === 3) {
      aggr_expr = this.visit(ctx.getChild(0));
      col_alias = this.visit(ctx.getChild(2));
    }
    const aggr_func = new AggrFunc(aggr_expr, col_alias);
    this.aggr_func_dict[aggr_expr.sql_expr] = aggr_func;
    this.aggr_func_dict[col_alias] = aggr_func;
    this.alias_2_field_map[col_alias] = aggr_func;
    return aggr_func;
  }

  /**
   * Visit a parse tree produced by `EasyParser.all_distinct`.
   * @param ctx the parse tree
   * @return the visitor result
   */
  visitAll_distinct(ctx: parser.All_distinctContext) {
    return ctx.text;
  }

  /**
   * Visit a parse tree produced by `EasyParser.order_item`.
   * @param ctx the parse tree
   * @return the visitor result
   */
  visitOrder_item(ctx: parser.Order_itemContext) {
    if (ctx.childCount === 1) {
      const expr = this.visit(ctx.getChild(0));
      return new OrderItem(expr);
    } else if (ctx.childCount === 2) {
      const expr = this.visit(ctx.getChild(0));
      const child1 = ctx.getChild(1).text;
      return new OrderItem(expr, child1);
    }
  }

  /**
   * Visit a parse tree produced by `EasyParser.true_false`.
   * @param ctx the parse tree
   * @return the visitor result
   */
  visitTrue_false(ctx: parser.True_falseContext) {
    return ctx.text;
  }

  /**
   * Visit a parse tree produced by `EasyParser.boolean_expression`.
   * @param ctx the parse tree
   * @return the visitor result
   */
  visitBoolean_expression(ctx: parser.Boolean_expressionContext) {
    if (ctx.childCount === 1) {
      return this.visit(ctx.getChild(0));
    } else if (ctx.childCount === 2) {
      // not predicate
      const not_ = ctx.getChild(0).text;
      const right = this.visit(ctx.getChild(1));
      return `${not_} ${right}`;
    } else if (ctx.childCount === 3) {
      if (ctx.getChild(0).text == "(") {
        //( boolean_expression )
        return `( ${this.visit(ctx.getChild(1))} )`;
      } else {
        // boolean_expression and/or boolean_expression
        const left = this.visit(ctx.getChild(0));
        const logic_operator = ctx.getChild(1).text;
        const right = this.visit(ctx.getChild(2));
        return `${left} ${logic_operator} ${right}`;
      }
    } else if (ctx.childCount === 4) {
      //NOT ( boolean_expression )
      const child0 = ctx.getChild(0).text;
      const child1 = ctx.getChild(1).text;
      const child2 = this.visit(ctx.getChild(2));
      const child3 = ctx.getChild(3).text;
      return `${child0} ${child1} ${child2} ${child3}`;
    }
  }

  /**
   * Visit a parse tree produced by `EasyParser.pred`.
   * @param ctx the parse tree
   * @return the visitor result
   */
  visitPred(ctx: parser.PredContext) {
    if (ctx.childCount === 3) {
      if (ctx.getChild(1) instanceof ErrorNode) {
        throw new Error(ctx.getChild(1).text);
      }
      const key = this.visit(ctx.getChild(0));
      const operator = this.visit(ctx.getChild(1));
      let value = this.visit(ctx.getChild(2));
      if (operator === "contains") {
        value = value.strip("'");
        return `${key} LIKE '%${value}%'`;
      } else if (operator == "startswith") {
        value = value.strip("'");
        return `${key} LIKE '${value}%'`;
      } else if (operator == "endswith") {
        value = value.strip("'");
        return `${key} LIKE '%${value}'`;
      } else {
        return `${key} ${operator} ${value}`;
      }
    }

    if ([5, 6].includes(ctx.childCount)) {
      const key = this.visit(ctx.getChild(0));
      let not_str, operator_index;
      if (this._is_terminal_token(ctx.getChild(1), parser.EasyParser.NOT)) {
        not_str = "NOT ";
        operator_index = 2;
      } else {
        not_str = "";
        operator_index = 1;
      }
      if (
        this._is_terminal_token(
          ctx.getChild(operator_index),
          parser.EasyParser.BETWEEN
        ) &&
        this._is_terminal_token(
          ctx.getChild(operator_index + 2),
          parser.EasyParser.AND
        )
      ) {
        const min_value = this.visit(ctx.getChild(operator_index + 1));
        const max_value = this.visit(ctx.getChild(operator_index + 3));
        return `${not_str}${key} >= ${min_value} AND ${key} <= ${max_value}`;
      }

      if (
        this._is_terminal_token(
          ctx.getChild(operator_index),
          parser.EasyParser.IN
        ) &&
        this._is_terminal_token(
          ctx.getChild(operator_index + 1),
          parser.EasyParser.LP
        ) &&
        this._is_terminal_token(
          ctx.getChild(ctx.childCount - 1),
          parser.EasyParser.RP
        )
      ) {
        const values = this.visit(ctx.getChild(operator_index + 2));
        return `${key} ${not_str}IN (${values})`;
      }
    }
    const msg = `Invalid predicate: {' '.join([ctx.getChild(i).getText() for i in range(ctx.getChildCount())])}`;
    throw new Error(msg);
  }

  /**
   * Visit a parse tree produced by `EasyParser.comparison_operator`.
   * @param ctx the parse tree
   * @return the visitor result
   */
  visitComparison_operator(ctx: parser.Comparison_operatorContext) {
    return ctx.text;
  }

  /**
   * Visit a parse tree produced by `EasyParser.match_operator`.
   * @param ctx the parse tree
   * @return the visitor result
   */
  visitMatch_operator(ctx: parser.Match_operatorContext) {
    return ctx.text.toLowerCase();
  }

  /**
   * Visit a parse tree produced by `EasyParser.expression_list_`.
   * @param ctx the parse tree
   * @return the visitor result
   */
  visitExpression_list_(ctx: parser.Expression_list_Context) {
    const evaluated_expressions = [];
    for (let i = 0; i < ctx.childCount; i++) {
      const expr = this.visit(ctx.getChild(i));
      if (expr) {
        evaluated_expressions.push(expr);
      }
    }
    return evaluated_expressions.join(", ");
  }

  /**
   * Visit a parse tree produced by `EasyParser.expression`.
   * @param ctx the parse tree
   * @return the visitor result
   */
  visitExpression(ctx: parser.ExpressionContext) {
    let result = "";
    if (ctx.childCount === 1) {
      return this.visit(ctx.getChild(0));
    } else {
      for (let i = 0; i < ctx.childCount; i++) {
        let text = this.visit(ctx.getChild(i));
        if (!text) {
          text = ctx.getChild(i).text;
        }
        result = `${result}${text}`;
        if (["all", "distinct"].includes(result.toLowerCase())) {
          result += " ";
        }
      }
      return result;
    }
  }

  /**
   * Visit a parse tree produced by `EasyParser.aggr_expression`.
   * @param ctx the parse tree
   * @return the visitor result
   */
  visitAggr_expression(ctx: parser.Aggr_expressionContext) {
    let aggr_func_name = this.visit(ctx.getChild(0));
    if (!aggr_func_name) {
      aggr_func_name = ctx.getChild(0).text;
    }
    let result = aggr_func_name;
    let is_distinct = false;
    for (let i = 1; i < ctx.childCount; i++) {
      let text = this.visit(ctx.getChild(i));
      if (!text) {
        text = ctx.getChild(i).text;
      }
      result = `${result}${text}`;
      if (["all", "distinct"].includes(text.toLowerCase())) {
        result += " ";
        if (text.toLowerCase() === "distinct") {
          is_distinct = true;
        }
      }
    }
    if (["count", "count()"].includes(result.toLowerCase())) {
      result = "count(*)";
    }
    return new AggrExpr(aggr_func_name, is_distinct, result);
  }

  /**
   * Visit a parse tree produced by `EasyParser.primitive_expression`.
   * @param ctx the parse tree
   * @return the visitor result
   */
  visitPrimitive_expression(ctx: parser.Primitive_expressionContext) {
    return this.visitChildren(ctx);
  }

  /**
   * Visit a parse tree produced by `EasyParser.time_span`.
   * @param ctx the parse tree
   * @return the visitor result
   */
  visitTime_span(ctx: parser.Time_spanContext) {
    let num = this.visit(ctx.getChild(0));
    if (num < 1) {
      throw new Error("Number of units must be a positive number");
    }
    let interval = this.visit(ctx.getChild(1));
    let fixed_interval = 0;
    let calendar_interval = "";
    if (interval === "s") {
      fixed_interval = num * 1000;
    } else if (interval === "m") {
      fixed_interval = num * 60 * 1000;
    } else if (interval == "h") {
      fixed_interval = num * 60 * 60 * 1000;
    } else if (interval == "d") {
      fixed_interval = num * 60 * 60 * 24 * 1000;
    } else if (interval == "w") {
      if (num > 1) {
        throw new Error("Multiple units are not allowed for week");
      } else {
        calendar_interval =
          "date_trunc('week', from_unixtime(event_time/1000))";
      }
    } else if (interval == "mon") {
      if (num > 1) {
        throw new Error("Multiple units are not allowed for month");
      } else {
        calendar_interval =
          "date_trunc('month', from_unixtime(event_time/1000))";
      }
    } else if (interval == "y") {
      if (num > 1) {
        throw new Error("Multiple units are not allowed for year");
      } else {
        calendar_interval =
          "date_trunc('year', from_unixtime(event_time/1000))";
      }
    }
    return {
      fixed_interval: fixed_interval,
      calendar_interval: calendar_interval,
      interval: interval,
    };
  }

  /**
   * Visit a parse tree produced by `EasyParser.time_interval`.
   * @param ctx the parse tree
   * @return the visitor result
   */
  visitTime_interval(ctx: parser.Time_intervalContext) {
    return ctx.text.toLowerCase();
  }

  /**
   * Visit a parse tree produced by `EasyParser.literal`.
   * @param ctx the parse tree
   * @return the visitor result
   */
  visitLiteral(ctx: parser.LiteralContext) {
    return this.visitChildren(ctx);
  }

  /**
   * Visit a parse tree produced by `EasyParser.int_number`.
   * @param ctx the parse tree
   * @return the visitor result
   */
  visitInt_number(ctx: parser.Int_numberContext) {
    return parseInt(ctx.text);
  }

  /**
   * Visit a parse tree produced by `EasyParser.number`.
   * @param ctx the parse tree
   * @return the visitor result
   */
  visitNumber(ctx: parser.NumberContext) {
    const number = this.visitChildren(ctx);
    return parseFloat(number);
  }

  /**
   * Visit a parse tree produced by `EasyParser.table_name`.
   * @param ctx the parse tree
   * @return the visitor result
   */
  visitTable_name(ctx: parser.Table_nameContext) {
    if (ctx.getChild(0) instanceof ErrorNode) {
      throw new Error(ctx.text);
    }
    return ctx.text;
  }

  /**
   * Visit a parse tree produced by `EasyParser.column_alias`.
   * @param ctx the parse tree
   * @return the visitor result
   */
  visitColumn_alias(ctx: parser.Column_aliasContext) {
    const alias = this.visit(ctx.getChild(0));
    this.aliases.push(alias);
    return alias;
  }

  /**
   * Visit a parse tree produced by `EasyParser.column`.
   * @param ctx the parse tree
   * @return the visitor result
   */
  visitColumn(ctx: parser.ColumnContext) {
    const col = this.visit(ctx.getChild(0));
    let alias, col_expr;
    if (ctx.childCount === 3) {
      //expression as alias
      alias = this.visit(ctx.getChild(2));
    }
    if (col instanceof AggrExpr) {
      const aggr_func = this.aggr_func_dict.get(col.sql_expr);
      if (!aggr_func) {
        throw new Error(col.orig_name);
      }
      if (alias) {
        aggr_func.alias = alias;
      }
      col_expr = aggr_func;
    } else {
      col_expr = new ColumnExpr(col, alias);
      if (alias) {
        this.alias_2_field_map[alias] = col;
      } else if (this.aliases.includes(col)) {
        const expr = this.alias_2_field_map.get(col);
        if (expr instanceof AggrFunc) {
          col_expr = expr;
        } else {
          col_expr = new ColumnExpr(expr, col);
        }
      }
    }
    return col_expr;
  }

  /**
   * Visit a parse tree produced by `EasyParser.string`.
   * @param ctx the parse tree
   * @return the visitor result
   */
  visitString(ctx: parser.StringContext) {
    let value = ctx.text;
    if (Array.isArray(value)) {
      if (value[0] === "'" && value[value.length - 1] === "'") {
        return value;
      } else if (value[0] === '"' && value[value.length - 1] === '"') {
        try {
          value = JSON.parse(value);
        } catch (e) {
          //
        }
        return `'${value}'`;
      }
    } else {
      return value;
    }
  }

  /**
   * Visit a parse tree produced by `EasyParser.id_`.
   * @param ctx the parse tree
   * @return the visitor result
   */
  visitId_(ctx: parser.Id_Context) {
    let text = ctx.text;
    text = text.indexOf(".") < 0 ? text : `"${text}"`;
    if (ctx.parent instanceof parser.Primitive_expressionContext) {
      if (
        !(
          this.columns.includes(text.toLowerCase()) ||
          this.aliases.includes(text)
        )
      ) {
        throw new Error("unknown identifier:" + text);
      }
    }
    return text;
  }

  defaultResult() {
    return "";
  }
}
