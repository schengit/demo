import { ParseTree } from "antlr4ts/tree/ParseTree";
import { TerminalNode } from "antlr4ts/tree/TerminalNode";
import FuzzySearch from 'fuzzy-search';

import { CaretPosition, Configuration, Suggestion, SuggestionContext, SuggestionType, TokenPosition, tokenTypeMapping } from "./types";
import { EasyParser } from "./generated/EasyParser";
import { Token } from "antlr4ts";


export async function extractTokens(context: SuggestionContext, config: Configuration): Promise<Suggestion[]> {
    return await Array.from(context.candidates.tokens.entries())
        .filter(([token, ]) => !config.SkippedTokens.has(token))
        .reduce(async (accumulator, [token, tokenList]) => {
            const suggestions = await accumulator;
            const tokenType = getTypeOf(token, context);
            let tokenSuggestions: Suggestion[] = [{ type: tokenType, value: clearTokenDisplayName(context.parser.vocabulary.getDisplayName(token)!.toLowerCase()) }];

            if (config.TokenSuggestionResolver.has(token)) {
                tokenSuggestions = await ((config.TokenSuggestionResolver.get(token)?.(token, tokenList, context, config)) ?? Promise.resolve([]));
            }

            if (context.textToMatch.trim().length > 0) {
                tokenSuggestions = filterSuggestions(tokenSuggestions, context.textToMatch.toLowerCase());

                for (const suggestion of tokenSuggestions) {
                    suggestion.position = {start: context.textStart, stop: context.textStop};
                }
            }

            return [...suggestions, ...tokenSuggestions];
        }, Promise.resolve<Suggestion[]>([]));
}

function clearTokenDisplayName(name: string): string {
    if (name) {
        if (name[0] === "'" && name.slice(-1)[0] === "'") {
            return name.slice(1, -1);
        }

        if (name[0] === '"' && name.slice(-1)[0] === '"') {
            return name.slice(1, -1);
        }
    }

    return name;
}

export async function extractRules(context: SuggestionContext, config: Configuration): Promise<Suggestion[]> {
    return await Array.from(context.candidates.rules.entries())
        .reduce(async (accumulator, [ruleCode, candidateRule]) => {
            const suggestions = await accumulator;
            let ruleSuggestions = await ((config.RuleSuggestionResolver.get(ruleCode)?.(ruleCode, candidateRule, context, config)) ?? Promise.resolve([]));

            if (context.textToMatch.trim().length > 0) {
                ruleSuggestions = filterSuggestions(ruleSuggestions, context.textToMatch.toLowerCase());

                for (const suggestion of ruleSuggestions) {
                    suggestion.position = {start: context.textStart, stop: context.textStop};
                }
            }

            return [...suggestions, ...ruleSuggestions];
        }, Promise.resolve<Suggestion[]>([]));
}

function filterSuggestions(suggestions: Suggestion[], term: string): Suggestion[] {
    const searcher = new FuzzySearch(suggestions, ['value'], {caseSensitive: false});
    return searcher.search(term);
}

export function computeTokenPosition(tree: ParseTree, caretPosition: CaretPosition): TokenPosition | undefined {
    if (tree instanceof TerminalNode) {
        return computeTokenIndexOfTerminalNode(tree, caretPosition);
    }
    return computeTokenIndexOfChildNode(tree, caretPosition);
}

function computeTokenIndexOfTerminalNode(node: TerminalNode, caretPosition: CaretPosition): TokenPosition | undefined {
    let start = node.symbol.charPositionInLine;
    let stop = node.symbol.charPositionInLine + node.text.length;

    if (node.symbol.line === caretPosition.line && start <= caretPosition.column && stop >= caretPosition.column) {
        return {
            index: node.symbol.tokenIndex,
            context: node,
            text: node.text.substring(0, caretPosition.column - start),
        };
    }

    return undefined;
}

function computeTokenIndexOfChildNode(tree: ParseTree, caretPosition: CaretPosition): TokenPosition | undefined {
    for (let i = 0; i < tree.childCount; i++) {
        let position = computeTokenPosition(tree.getChild(i), caretPosition);
        if (position !== undefined) {
            return position;
        }
    }

    return undefined;
}

export function sortSuggestionsByImportance(suggestions: Suggestion[]): Suggestion[] {
    const typeWeigth: {[type in SuggestionType]: number} = {
        identifier: 0,
        string: 1,
        number: 1,
        boolean: 1,
        operator: 2,
        table: 3,
        function: 4,
        keyword: 5,
        timeunit: 6,
        symbol: 7,
        any: 11,
        comment: 12,
        error: 13,
    }

    function getWeight(type: SuggestionType): number {
        return typeWeigth[type] ?? 0;
    }

    return suggestions.sort((a, b) => {
        return getWeight(a.type) - getWeight(b.type);
    });
}

export function merge<K, V>(a: Map<K, V>, b?: Map<K, V>): Map<K, V> {
    if (!b) {
        return a;
    }

    return new Map<K, V>([
        ...a.entries(),
        ...b.entries(),
    ]);
}

export function getTypeOf(token: number, context: SuggestionContext): SuggestionType {
    const tokens = context.tokens.getTokens();

    let tokenIndex = context.tokenIndex;
    if (tokenIndex === undefined && tokens.slice(-1)[0]?.type === EasyParser.EOF) {
        tokenIndex = tokens.length - 1;
    }

    if (typeof tokenIndex === 'number') {
        const tokenRightBefore = getTokenRightBeforeTokenAt(tokenIndex, tokens, [EasyParser.WS]);
        if (tokenRightBefore === EasyParser.PIPE && tokens[tokenIndex]?.type !== EasyParser.WS) {
            return 'operator';
        }
    }
    return tokenTypeMapping.get(token) ?? 'any';
}

function getTokenRightBeforeTokenAt(tokenIndex: number, tokens: Array<Token>, ignore: Array<number>): number | undefined {
    let index = tokenIndex - 1;
    if(!tokens) {
        return;
    }
    while (index >= 0) {
        const type = tokens[index]?.type;
        if(!type) {
            return;
        }
        if (ignore.includes(type)) {
            index -= 1;
            continue;
        }
        return type;
    }
    return;
}
