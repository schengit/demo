import { CharStreams, CommonTokenStream } from "antlr4ts";
import { CodeCompletionCore } from "antlr4-c3";

import { EasyParser } from "./generated/EasyParser";
import { EasyLexer } from "./generated/EasyLexer";
import {
  CaretPosition,
  Configuration,
  Suggestion,
  SuggestionContext,
} from "./types";

import {
  computeTokenPosition,
  extractRules,
  extractTokens,
  getTypeOf,
  merge,
  sortSuggestionsByImportance,
} from "./utils";

import {
  tableSuggestions,
  columnsSuggestions,
  emptyResolver,
  stringValuesSuggestions,
  valuesSuggestions,
} from "./resolvers";
import { TerminalNode } from "antlr4ts/tree/TerminalNode";
import { CaseChangingCharStream } from "./streams";

const BuiltInRuleResolvers: Configuration["RuleSuggestionResolver"] = new Map([
  [EasyParser.RULE_id_, columnsSuggestions],
  [EasyParser.RULE_table_name, tableSuggestions],
  [EasyParser.RULE_column, columnsSuggestions],

  //[EasyParser.RULE_left_column, columnsSuggestions],
  //[EasyParser.RULE_right_column, columnsSuggestions],
  //[EasyParser.RULE_right_table_column, columnsSuggestions],
  [EasyParser.RULE_literal, valuesSuggestions],
  [EasyParser.RULE_string, stringValuesSuggestions],
]);

export namespace EasyAutoComplete {
  export const Config: Configuration = {
    IgnoredTokens: new Set([
      EasyParser.EVENTLOG,
      EasyParser.INTEGRAL_LITERAL,
      EasyParser.REAL_LITERAL,
      EasyParser.FLOAT_LITERAL,
      EasyParser.SQ_STRING_LITERAL,
      EasyParser.DQ_STRING_LITERAL,
      EasyParser.WS,
    ]),
    SkippedTokens: new Set([EasyParser.IDENTIFIER, EasyParser.EOF]),
    TokenSuggestionResolver: new Map([]),
    RuleSuggestionResolver: new Map([
      //[EasyParser.RULE_right_table, emptyResolver],
    ]),
  };

  export async function suggestions(
    query: string,
    { line, column }: CaretPosition
  ): Promise<Suggestion[]> {
    const stream = CharStreams.fromString(query);
    const input = new CaseChangingCharStream(stream, true);
    const lexer = new EasyLexer(input);
    const tokens = new CommonTokenStream(lexer);
    const parser = new EasyParser(tokens);
    const config = {
      ...Config,
      RuleSuggestionResolver: merge(
        Config.RuleSuggestionResolver,
        BuiltInRuleResolvers
      ),
    };

    for (const [rule] of Config.RuleSuggestionResolver.entries()) {
      if (BuiltInRuleResolvers.has(rule)) {
        console.log(
          `Ignoring resolver for rule ${parser.vocabulary.getSymbolicName(rule)}, using built-in resolver.`
        );
      }
    }

    lexer.removeErrorListeners();
    parser.removeErrorListeners();

    const completion = new CodeCompletionCore(parser);
    completion.ignoredTokens = config.IgnoredTokens;
    completion.preferredRules = new Set(config.RuleSuggestionResolver.keys());

    const position = computeTokenPosition(parser.eql(), {
      line: line + 1,
      column: column + 1,
    });
    const candidates = completion.collectCandidates(
      position?.index as unknown as number
    );

    const node = position?.context as TerminalNode;
    const isIgnoredToken =
      node instanceof TerminalNode &&
      config.IgnoredTokens.has(node?.symbol?.type);
    const textToMatch = (isIgnoredToken ? "" : position?.text) ?? "";
    const tokenIndex = node?.symbol?.tokenIndex;
    const textStart = node?.symbol?.startIndex;
    const textStop = node?.symbol?.stopIndex;

    const tokenSuggestions = await extractTokens(
      {
        parser,
        candidates,
        tokens,
        textToMatch,
        tokenIndex,
        textStart,
        textStop,
      },
      config
    );
    const rulesSuggestions = await extractRules(
      {
        parser,
        candidates,
        tokens,
        textToMatch,
        tokenIndex,
        textStart,
        textStop,
      },
      config
    );

    //(window as any).parser = parser;
    return sortSuggestionsByImportance([
      ...tokenSuggestions,
      ...rulesSuggestions,
    ]);
  }

  export async function tokenize(query: string): Promise<Suggestion[]> {
    if (!query) {
      return [];
    }
    const unrecognizedTokens: Suggestion[] = [];

    const stream = CharStreams.fromString(query);
    const input = new CaseChangingCharStream(stream, true);
    const lexer = new EasyLexer(input);
    const tokens = new CommonTokenStream(lexer);

    lexer.removeErrorListeners();
    lexer.addErrorListener(
      new TokenizeUnsupportedCharacters(query, unrecognizedTokens)
    );
    //tokens.consume();
    //tokens.getText();
    tokens.fill();

    const recognizedTokens = tokens
      .getTokens()
      .filter((token) => token.type !== EasyParser.EOF)
      .map((token, tokenIndex) => {
        return {
          value: token.text ?? "",
          type: getTypeOf(token.type, {
            tokenIndex,
            tokens,
          } as SuggestionContext),
          position: {
            start: token.startIndex,
            stop: token.stopIndex,
          },
        };
      });

    console.log("unrecognizedTokens", unrecognizedTokens);
    return [...recognizedTokens, ...unrecognizedTokens].sort(
      (a, b) => a.position!.start! - b.position!.start!
    );
  }
}

class TokenizeUnsupportedCharacters {
  /**
   * Handles an error and procudes a Suggestion item to use for
   * tokenization of the query.
   */
  query: string;
  results: Suggestion[];

  constructor(query: string, results: Suggestion[]) {
    this.query = query;
    this.results = results;
  }

  syntaxError(
    recognizer: any,
    offendingSymbol: any,
    line: number,
    charPositionInLine: number,
    msg: string,
    e: any
  ) {
    const index = this.computeIndex(line - 1, charPositionInLine);
    const character = this.query[index]?.trim() || "";

    this.results.push({
      type: "error",
      value: character,
      position: { start: index, stop: index },
    });
  }

  private computeIndex(line: number, column: number): number {
    const lines = this.query.split("\n");
    const previousLines = lines.slice(0, line);
    return (
      previousLines.reduce((count, line) => count + line.length + 1, 0) + column
    );
  }
}
