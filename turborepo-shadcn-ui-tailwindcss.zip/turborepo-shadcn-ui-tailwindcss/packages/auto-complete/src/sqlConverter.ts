import { CharStreams, CommonTokenStream } from "antlr4ts";
import { CodeCompletionCore } from "antlr4-c3";

import { EasyParser } from "./generated/EasyParser";
import { EasyLexer } from "./generated/EasyLexer";
import {
  CaretPosition,
  Configuration,
  Suggestion,
  SuggestionContext,
} from "./types";

import {
  computeTokenPosition,
  extractRules,
  extractTokens,
  getTypeOf,
  merge,
  sortSuggestionsByImportance,
} from "./utils";

import {
  tableSuggestions,
  columnsSuggestions,
  emptyResolver,
  stringValuesSuggestions,
  valuesSuggestions,
} from "./resolvers";

import { TerminalNode } from "antlr4ts/tree/TerminalNode";
import { CaseChangingCharStream } from "./streams";

import {
  ANTLRErrorListener,
  Recognizer,
  RecognitionException,
  Token,
} from "antlr4ts";

import {
  EasyQLVisitor,
  ColumnExpr,
  AggrExpr,
  AggrFunc,
  OrderItem,
} from "./easyVisitor";

class ErrorListener implements ANTLRErrorListener<Token> {
  syntaxError(
    recognizer: Recognizer<Token, any>,
    offendingSymbol: Token | undefined,
    line: number,
    charPositionInLine: number,
    msg: string,
    e: RecognitionException | undefined
  ): void {
    console.log(`Syntax error at line ${line}:${charPositionInLine}: ${msg}`);
  }
}

export class SQLConverter {
  parsed_fragments: Record<string, any>[] = [];
  is_aggregated = false;
  is_sorted = false;
  filters = "";
  column_map: Record<string, any> = {};
  can_be_reduced = false;
  output_columns: string[] = [];
  limit = 1000;

  remove_duplicates(list: string[]) {
    const result: string[] = [];
    for (const l of list) {
      if (!result.includes(l)) {
        result.push(l);
      }
    }
    return result;
  }

  exists_column(column_name: string, columns_expr: ColumnExpr[]) {
    if (!columns_expr) {
      return false;
    }
    for (const col_expr of columns_expr) {
      if (col_expr) {
        return column_name == col_expr.column || column_name == col_expr.alias;
      } else {
        return false;
      }
    }
  }

  getSql(query: string) {
    this.parse(query);

    //this is a simple sql generator: can only handle one where and one aggr operator
    const key_maps: Record<string, any> = {
      table: "",
      condition: "",
      columns: [],
      limit: 1000,
    };
    let columns_expr, order_items;
    for (let fragment of this.parsed_fragments) {
      if ("from" in fragment) {
        key_maps["table"] = fragment["from"];
      } else if ("where" in fragment) {
        if (this.is_aggregated) {
          key_maps["having"] = fragment["where"];
        } else {
          this.filters = fragment["where"];
          key_maps["condition"] = key_maps["condition"]
            ? `${key_maps["condition"]} and (${fragment["where"]})`
            : `${fragment["where"]}`;
        }
      } else if ("projected_fields" in fragment) {
        this.is_aggregated = true;
        const agg_fields = [...fragment["projected_fields"]];
        if ("group by" in fragment) {
          key_maps["groupby"] = fragment["group by"];
        }
        key_maps["columns"] = agg_fields;
        let can_be_reduced = true;
        for (let aggr_func of fragment["aggr_func"]) {
          can_be_reduced =
            can_be_reduced && aggr_func.aggr_expr.can_be_reduced();
          this.column_map[aggr_func.column] = aggr_func;
        }
        this.can_be_reduced = can_be_reduced;
      } else if ("order by" in fragment) {
        this.is_sorted = true;
        order_items = fragment["order by"];
        const orderby = [];
        for (let oby of fragment["order by"]) {
          orderby.push(oby);
        }
        key_maps["orderby"] = orderby;
      } else if ("fields" in fragment) {
        columns_expr = fragment["fields"];
        const fields: string[] = [];
        const output_columns: string[] = [];
        for (let field of fragment["fields"]) {
          fields.push(field.get_column_expr());
          output_columns.push(field.get_alias());
        }
        this.output_columns = output_columns;
        if (
          this.is_aggregated ||
          fields.includes("*") ||
          fields.includes("_raw_id")
        ) {
          key_maps["columns"] = fields;
          if (this.is_aggregated) {
            for (const field of fragment["fields"]) {
              this.column_map[field.column] = field;
            }
          }
        } else {
          key_maps["columns"] = fields; //+ get_event_meta_fields()
          //this.output_columns = this.output_columns + get_event_meta_fields()
          /*
            if "event_time" not in kv_maps["columns"]:
                #always add event_time to non-aggr results as it's required for fetching raw event
                kv_maps["columns"] = ["event_time"] + kv_maps["columns"]
                self.output_columns = ["event_time"] + self.output_columns
            */
        }
        key_maps["columns"] = this.remove_duplicates(key_maps["columns"]);
      } else if ("limit" in fragment) {
        this.limit = parseInt(fragment["limit"]);
        key_maps["limit"] = fragment["limit"];
      }
    }
    if (
      this.is_sorted &&
      !this.is_aggregated &&
      !("*" in key_maps["columns"])
    ) {
      const missing_cols: string[] = [];
      for (const item of order_items) {
        if (
          !(item.column in key_maps["columns"]) &&
          !this.exists_column(item.column, columns_expr)
        ) {
          missing_cols.push(item.column);
        }
      }
      key_maps["columns"] = key_maps["columns"].concat(missing_cols);
    }
    const columns = this.remove_duplicates(key_maps["columns"]).join(", ");
    const table = key_maps["table"];
    const condition = key_maps["condition"];
    let sql = `SELECT ${columns} FROM ${table} WHERE ${condition}`;
    if ("groupby" in key_maps) {
      const groupby_fields = key_maps["groupby"].join(",");
      sql += ` GROUP BY ${groupby_fields}`;
    }
    //TODO having should be pushed to reduce phase
    if ("having" in key_maps) {
      sql += ` HAVING ${key_maps["having"]}`;
    }
    if ("orderby" in key_maps) {
      const orderby_fields = key_maps["orderby"].join(",");
      sql += ` ORDER BY ${orderby_fields}`;
    }
    sql += ` LIMIT ${this.limit}`;
    return sql;
  }

  parse(query: string) {
    const stream = CharStreams.fromString(query);
    const input = new CaseChangingCharStream(stream, true);
    const lexer = new EasyLexer(input);
    const tokens = new CommonTokenStream(lexer);
    const parser = new EasyParser(tokens);
    parser.removeErrorListeners();
    parser.addErrorListener(new ErrorListener());
    //
    const tree = parser.eql();
    const fields = ["name", "sex", "age", "email", "birthday"];
    const visitor = new EasyQLVisitor(fields);
    const parsed_fragments = visitor.visit(tree);

    this.parsed_fragments = parsed_fragments;

    console.log(parsed_fragments);
    //return parsed_fragments;
  }
}
