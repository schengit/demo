import { SQLConverter } from "./sqlConverter";

it("should get sql", async () => {
  const query = `from user | fields name, age | where name = "tom" and age > 20 | stats count() as cnt  by sex, age | sort cnt desc`;
  const converter = new SQLConverter();
  const result = converter.getSql(query);
  console.log(result);
  expect(result.length).toBeGreaterThan(0);
});
