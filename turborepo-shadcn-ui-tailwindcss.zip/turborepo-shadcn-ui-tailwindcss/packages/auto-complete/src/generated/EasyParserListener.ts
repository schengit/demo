// Generated from grammar/EasyParser.g4 by ANTLR 4.9.0-SNAPSHOT


import { ParseTreeListener } from "antlr4ts/tree/ParseTreeListener";

import { EqlContext } from "./EasyParser";
import { From_itemContext } from "./EasyParser";
import { Where_operatorContext } from "./EasyParser";
import { Aggr_operatorContext } from "./EasyParser";
import { Sort_operatorContext } from "./EasyParser";
import { Fields_operatorContext } from "./EasyParser";
import { Limit_operatorContext } from "./EasyParser";
import { Grouping_elementContext } from "./EasyParser";
import { Aggr_funcContext } from "./EasyParser";
import { All_distinctContext } from "./EasyParser";
import { Order_itemContext } from "./EasyParser";
import { True_falseContext } from "./EasyParser";
import { Boolean_expressionContext } from "./EasyParser";
import { PredContext } from "./EasyParser";
import { Comparison_operatorContext } from "./EasyParser";
import { Match_operatorContext } from "./EasyParser";
import { Expression_list_Context } from "./EasyParser";
import { ExpressionContext } from "./EasyParser";
import { Aggr_expressionContext } from "./EasyParser";
import { Primitive_expressionContext } from "./EasyParser";
import { Time_spanContext } from "./EasyParser";
import { Time_intervalContext } from "./EasyParser";
import { LiteralContext } from "./EasyParser";
import { Int_numberContext } from "./EasyParser";
import { NumberContext } from "./EasyParser";
import { Table_nameContext } from "./EasyParser";
import { Column_aliasContext } from "./EasyParser";
import { ColumnContext } from "./EasyParser";
import { StringContext } from "./EasyParser";
import { Id_Context } from "./EasyParser";


/**
 * This interface defines a complete listener for a parse tree produced by
 * `EasyParser`.
 */
export interface EasyParserListener extends ParseTreeListener {
	/**
	 * Enter a parse tree produced by `EasyParser.eql`.
	 * @param ctx the parse tree
	 */
	enterEql?: (ctx: EqlContext) => void;
	/**
	 * Exit a parse tree produced by `EasyParser.eql`.
	 * @param ctx the parse tree
	 */
	exitEql?: (ctx: EqlContext) => void;

	/**
	 * Enter a parse tree produced by `EasyParser.from_item`.
	 * @param ctx the parse tree
	 */
	enterFrom_item?: (ctx: From_itemContext) => void;
	/**
	 * Exit a parse tree produced by `EasyParser.from_item`.
	 * @param ctx the parse tree
	 */
	exitFrom_item?: (ctx: From_itemContext) => void;

	/**
	 * Enter a parse tree produced by `EasyParser.where_operator`.
	 * @param ctx the parse tree
	 */
	enterWhere_operator?: (ctx: Where_operatorContext) => void;
	/**
	 * Exit a parse tree produced by `EasyParser.where_operator`.
	 * @param ctx the parse tree
	 */
	exitWhere_operator?: (ctx: Where_operatorContext) => void;

	/**
	 * Enter a parse tree produced by `EasyParser.aggr_operator`.
	 * @param ctx the parse tree
	 */
	enterAggr_operator?: (ctx: Aggr_operatorContext) => void;
	/**
	 * Exit a parse tree produced by `EasyParser.aggr_operator`.
	 * @param ctx the parse tree
	 */
	exitAggr_operator?: (ctx: Aggr_operatorContext) => void;

	/**
	 * Enter a parse tree produced by `EasyParser.sort_operator`.
	 * @param ctx the parse tree
	 */
	enterSort_operator?: (ctx: Sort_operatorContext) => void;
	/**
	 * Exit a parse tree produced by `EasyParser.sort_operator`.
	 * @param ctx the parse tree
	 */
	exitSort_operator?: (ctx: Sort_operatorContext) => void;

	/**
	 * Enter a parse tree produced by `EasyParser.fields_operator`.
	 * @param ctx the parse tree
	 */
	enterFields_operator?: (ctx: Fields_operatorContext) => void;
	/**
	 * Exit a parse tree produced by `EasyParser.fields_operator`.
	 * @param ctx the parse tree
	 */
	exitFields_operator?: (ctx: Fields_operatorContext) => void;

	/**
	 * Enter a parse tree produced by `EasyParser.limit_operator`.
	 * @param ctx the parse tree
	 */
	enterLimit_operator?: (ctx: Limit_operatorContext) => void;
	/**
	 * Exit a parse tree produced by `EasyParser.limit_operator`.
	 * @param ctx the parse tree
	 */
	exitLimit_operator?: (ctx: Limit_operatorContext) => void;

	/**
	 * Enter a parse tree produced by `EasyParser.grouping_element`.
	 * @param ctx the parse tree
	 */
	enterGrouping_element?: (ctx: Grouping_elementContext) => void;
	/**
	 * Exit a parse tree produced by `EasyParser.grouping_element`.
	 * @param ctx the parse tree
	 */
	exitGrouping_element?: (ctx: Grouping_elementContext) => void;

	/**
	 * Enter a parse tree produced by `EasyParser.aggr_func`.
	 * @param ctx the parse tree
	 */
	enterAggr_func?: (ctx: Aggr_funcContext) => void;
	/**
	 * Exit a parse tree produced by `EasyParser.aggr_func`.
	 * @param ctx the parse tree
	 */
	exitAggr_func?: (ctx: Aggr_funcContext) => void;

	/**
	 * Enter a parse tree produced by `EasyParser.all_distinct`.
	 * @param ctx the parse tree
	 */
	enterAll_distinct?: (ctx: All_distinctContext) => void;
	/**
	 * Exit a parse tree produced by `EasyParser.all_distinct`.
	 * @param ctx the parse tree
	 */
	exitAll_distinct?: (ctx: All_distinctContext) => void;

	/**
	 * Enter a parse tree produced by `EasyParser.order_item`.
	 * @param ctx the parse tree
	 */
	enterOrder_item?: (ctx: Order_itemContext) => void;
	/**
	 * Exit a parse tree produced by `EasyParser.order_item`.
	 * @param ctx the parse tree
	 */
	exitOrder_item?: (ctx: Order_itemContext) => void;

	/**
	 * Enter a parse tree produced by `EasyParser.true_false`.
	 * @param ctx the parse tree
	 */
	enterTrue_false?: (ctx: True_falseContext) => void;
	/**
	 * Exit a parse tree produced by `EasyParser.true_false`.
	 * @param ctx the parse tree
	 */
	exitTrue_false?: (ctx: True_falseContext) => void;

	/**
	 * Enter a parse tree produced by `EasyParser.boolean_expression`.
	 * @param ctx the parse tree
	 */
	enterBoolean_expression?: (ctx: Boolean_expressionContext) => void;
	/**
	 * Exit a parse tree produced by `EasyParser.boolean_expression`.
	 * @param ctx the parse tree
	 */
	exitBoolean_expression?: (ctx: Boolean_expressionContext) => void;

	/**
	 * Enter a parse tree produced by `EasyParser.pred`.
	 * @param ctx the parse tree
	 */
	enterPred?: (ctx: PredContext) => void;
	/**
	 * Exit a parse tree produced by `EasyParser.pred`.
	 * @param ctx the parse tree
	 */
	exitPred?: (ctx: PredContext) => void;

	/**
	 * Enter a parse tree produced by `EasyParser.comparison_operator`.
	 * @param ctx the parse tree
	 */
	enterComparison_operator?: (ctx: Comparison_operatorContext) => void;
	/**
	 * Exit a parse tree produced by `EasyParser.comparison_operator`.
	 * @param ctx the parse tree
	 */
	exitComparison_operator?: (ctx: Comparison_operatorContext) => void;

	/**
	 * Enter a parse tree produced by `EasyParser.match_operator`.
	 * @param ctx the parse tree
	 */
	enterMatch_operator?: (ctx: Match_operatorContext) => void;
	/**
	 * Exit a parse tree produced by `EasyParser.match_operator`.
	 * @param ctx the parse tree
	 */
	exitMatch_operator?: (ctx: Match_operatorContext) => void;

	/**
	 * Enter a parse tree produced by `EasyParser.expression_list_`.
	 * @param ctx the parse tree
	 */
	enterExpression_list_?: (ctx: Expression_list_Context) => void;
	/**
	 * Exit a parse tree produced by `EasyParser.expression_list_`.
	 * @param ctx the parse tree
	 */
	exitExpression_list_?: (ctx: Expression_list_Context) => void;

	/**
	 * Enter a parse tree produced by `EasyParser.expression`.
	 * @param ctx the parse tree
	 */
	enterExpression?: (ctx: ExpressionContext) => void;
	/**
	 * Exit a parse tree produced by `EasyParser.expression`.
	 * @param ctx the parse tree
	 */
	exitExpression?: (ctx: ExpressionContext) => void;

	/**
	 * Enter a parse tree produced by `EasyParser.aggr_expression`.
	 * @param ctx the parse tree
	 */
	enterAggr_expression?: (ctx: Aggr_expressionContext) => void;
	/**
	 * Exit a parse tree produced by `EasyParser.aggr_expression`.
	 * @param ctx the parse tree
	 */
	exitAggr_expression?: (ctx: Aggr_expressionContext) => void;

	/**
	 * Enter a parse tree produced by `EasyParser.primitive_expression`.
	 * @param ctx the parse tree
	 */
	enterPrimitive_expression?: (ctx: Primitive_expressionContext) => void;
	/**
	 * Exit a parse tree produced by `EasyParser.primitive_expression`.
	 * @param ctx the parse tree
	 */
	exitPrimitive_expression?: (ctx: Primitive_expressionContext) => void;

	/**
	 * Enter a parse tree produced by `EasyParser.time_span`.
	 * @param ctx the parse tree
	 */
	enterTime_span?: (ctx: Time_spanContext) => void;
	/**
	 * Exit a parse tree produced by `EasyParser.time_span`.
	 * @param ctx the parse tree
	 */
	exitTime_span?: (ctx: Time_spanContext) => void;

	/**
	 * Enter a parse tree produced by `EasyParser.time_interval`.
	 * @param ctx the parse tree
	 */
	enterTime_interval?: (ctx: Time_intervalContext) => void;
	/**
	 * Exit a parse tree produced by `EasyParser.time_interval`.
	 * @param ctx the parse tree
	 */
	exitTime_interval?: (ctx: Time_intervalContext) => void;

	/**
	 * Enter a parse tree produced by `EasyParser.literal`.
	 * @param ctx the parse tree
	 */
	enterLiteral?: (ctx: LiteralContext) => void;
	/**
	 * Exit a parse tree produced by `EasyParser.literal`.
	 * @param ctx the parse tree
	 */
	exitLiteral?: (ctx: LiteralContext) => void;

	/**
	 * Enter a parse tree produced by `EasyParser.int_number`.
	 * @param ctx the parse tree
	 */
	enterInt_number?: (ctx: Int_numberContext) => void;
	/**
	 * Exit a parse tree produced by `EasyParser.int_number`.
	 * @param ctx the parse tree
	 */
	exitInt_number?: (ctx: Int_numberContext) => void;

	/**
	 * Enter a parse tree produced by `EasyParser.number`.
	 * @param ctx the parse tree
	 */
	enterNumber?: (ctx: NumberContext) => void;
	/**
	 * Exit a parse tree produced by `EasyParser.number`.
	 * @param ctx the parse tree
	 */
	exitNumber?: (ctx: NumberContext) => void;

	/**
	 * Enter a parse tree produced by `EasyParser.table_name`.
	 * @param ctx the parse tree
	 */
	enterTable_name?: (ctx: Table_nameContext) => void;
	/**
	 * Exit a parse tree produced by `EasyParser.table_name`.
	 * @param ctx the parse tree
	 */
	exitTable_name?: (ctx: Table_nameContext) => void;

	/**
	 * Enter a parse tree produced by `EasyParser.column_alias`.
	 * @param ctx the parse tree
	 */
	enterColumn_alias?: (ctx: Column_aliasContext) => void;
	/**
	 * Exit a parse tree produced by `EasyParser.column_alias`.
	 * @param ctx the parse tree
	 */
	exitColumn_alias?: (ctx: Column_aliasContext) => void;

	/**
	 * Enter a parse tree produced by `EasyParser.column`.
	 * @param ctx the parse tree
	 */
	enterColumn?: (ctx: ColumnContext) => void;
	/**
	 * Exit a parse tree produced by `EasyParser.column`.
	 * @param ctx the parse tree
	 */
	exitColumn?: (ctx: ColumnContext) => void;

	/**
	 * Enter a parse tree produced by `EasyParser.string`.
	 * @param ctx the parse tree
	 */
	enterString?: (ctx: StringContext) => void;
	/**
	 * Exit a parse tree produced by `EasyParser.string`.
	 * @param ctx the parse tree
	 */
	exitString?: (ctx: StringContext) => void;

	/**
	 * Enter a parse tree produced by `EasyParser.id_`.
	 * @param ctx the parse tree
	 */
	enterId_?: (ctx: Id_Context) => void;
	/**
	 * Exit a parse tree produced by `EasyParser.id_`.
	 * @param ctx the parse tree
	 */
	exitId_?: (ctx: Id_Context) => void;
}

