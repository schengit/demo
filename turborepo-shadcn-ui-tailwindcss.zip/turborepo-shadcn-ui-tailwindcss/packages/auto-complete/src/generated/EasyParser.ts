// Generated from grammar/EasyParser.g4 by ANTLR 4.9.0-SNAPSHOT


import { ATN } from "antlr4ts/atn/ATN";
import { ATNDeserializer } from "antlr4ts/atn/ATNDeserializer";
import { FailedPredicateException } from "antlr4ts/FailedPredicateException";
import { NotNull } from "antlr4ts/Decorators";
import { NoViableAltException } from "antlr4ts/NoViableAltException";
import { Override } from "antlr4ts/Decorators";
import { Parser } from "antlr4ts/Parser";
import { ParserRuleContext } from "antlr4ts/ParserRuleContext";
import { ParserATNSimulator } from "antlr4ts/atn/ParserATNSimulator";
import { ParseTreeListener } from "antlr4ts/tree/ParseTreeListener";
import { ParseTreeVisitor } from "antlr4ts/tree/ParseTreeVisitor";
import { RecognitionException } from "antlr4ts/RecognitionException";
import { RuleContext } from "antlr4ts/RuleContext";
//import { RuleVersion } from "antlr4ts/RuleVersion";
import { TerminalNode } from "antlr4ts/tree/TerminalNode";
import { Token } from "antlr4ts/Token";
import { TokenStream } from "antlr4ts/TokenStream";
import { Vocabulary } from "antlr4ts/Vocabulary";
import { VocabularyImpl } from "antlr4ts/VocabularyImpl";

import * as Utils from "antlr4ts/misc/Utils";

import { EasyParserListener } from "./EasyParserListener";
import { EasyParserVisitor } from "./EasyParserVisitor";


export class EasyParser extends Parser {
	public static readonly STATS = 1;
	public static readonly ALL = 2;
	public static readonly AND = 3;
	public static readonly AS = 4;
	public static readonly ASC = 5;
	public static readonly AVG = 6;
	public static readonly BETWEEN = 7;
	public static readonly BY = 8;
	public static readonly CONTAINS = 9;
	public static readonly COUNT = 10;
	public static readonly DAY_ = 11;
	public static readonly DESC = 12;
	public static readonly DISTINCT = 13;
	public static readonly ENDSWITH = 14;
	public static readonly EVENTLOG = 15;
	public static readonly FALSE = 16;
	public static readonly FIELDS = 17;
	public static readonly FROM = 18;
	public static readonly HOUR_ = 19;
	public static readonly IN = 20;
	public static readonly LIMIT = 21;
	public static readonly MAX = 22;
	public static readonly MIN = 23;
	public static readonly MINUTE_ = 24;
	public static readonly MONTH_ = 25;
	public static readonly NOT = 26;
	public static readonly OR = 27;
	public static readonly SECOND_ = 28;
	public static readonly SORT = 29;
	public static readonly SPAN = 30;
	public static readonly STARTSWITH = 31;
	public static readonly SEARCH = 32;
	public static readonly SUM = 33;
	public static readonly TIMETREND = 34;
	public static readonly TO = 35;
	public static readonly TRUE = 36;
	public static readonly WEEK_ = 37;
	public static readonly WHERE = 38;
	public static readonly YEAR_ = 39;
	public static readonly PIPE = 40;
	public static readonly EQ = 41;
	public static readonly SEMI = 42;
	public static readonly LP = 43;
	public static readonly RP = 44;
	public static readonly DOT = 45;
	public static readonly COMMA = 46;
	public static readonly LT = 47;
	public static readonly GT = 48;
	public static readonly LE = 49;
	public static readonly GE = 50;
	public static readonly NE = 51;
	public static readonly BOX = 52;
	public static readonly COLON = 53;
	public static readonly QM = 54;
	public static readonly STAR = 55;
	public static readonly PLUS = 56;
	public static readonly MINUS = 57;
	public static readonly DIVIDE = 58;
	public static readonly MODULE = 59;
	public static readonly IDENTIFIER = 60;
	public static readonly SQ_STRING_LITERAL = 61;
	public static readonly DQ_STRING_LITERAL = 62;
	public static readonly INTEGRAL_LITERAL = 63;
	public static readonly FLOAT_LITERAL = 64;
	public static readonly REAL_LITERAL = 65;
	public static readonly WS = 66;
	public static readonly LINE_COMMENT = 67;
	public static readonly RULE_eql = 0;
	public static readonly RULE_from_item = 1;
	public static readonly RULE_where_operator = 2;
	public static readonly RULE_aggr_operator = 3;
	public static readonly RULE_sort_operator = 4;
	public static readonly RULE_fields_operator = 5;
	public static readonly RULE_limit_operator = 6;
	public static readonly RULE_grouping_element = 7;
	public static readonly RULE_aggr_func = 8;
	public static readonly RULE_all_distinct = 9;
	public static readonly RULE_order_item = 10;
	public static readonly RULE_true_false = 11;
	public static readonly RULE_boolean_expression = 12;
	public static readonly RULE_pred = 13;
	public static readonly RULE_comparison_operator = 14;
	public static readonly RULE_match_operator = 15;
	public static readonly RULE_expression_list_ = 16;
	public static readonly RULE_expression = 17;
	public static readonly RULE_aggr_expression = 18;
	public static readonly RULE_primitive_expression = 19;
	public static readonly RULE_time_span = 20;
	public static readonly RULE_time_interval = 21;
	public static readonly RULE_literal = 22;
	public static readonly RULE_int_number = 23;
	public static readonly RULE_number = 24;
	public static readonly RULE_table_name = 25;
	public static readonly RULE_column_alias = 26;
	public static readonly RULE_column = 27;
	public static readonly RULE_string = 28;
	public static readonly RULE_id_ = 29;
	// tslint:disable:no-trailing-whitespace
	public static readonly ruleNames: string[] = [
		"eql", "from_item", "where_operator", "aggr_operator", "sort_operator", 
		"fields_operator", "limit_operator", "grouping_element", "aggr_func", 
		"all_distinct", "order_item", "true_false", "boolean_expression", "pred", 
		"comparison_operator", "match_operator", "expression_list_", "expression", 
		"aggr_expression", "primitive_expression", "time_span", "time_interval", 
		"literal", "int_number", "number", "table_name", "column_alias", "column", 
		"string", "id_",
	];

	private static readonly _LITERAL_NAMES: Array<string | undefined> = [
		undefined, "'STATS'", "'ALL'", "'AND'", "'AS'", "'ASC'", "'AVG'", "'BETWEEN'", 
		"'BY'", "'CONTAINS'", "'COUNT'", "'D'", "'DESC'", "'DISTINCT'", "'ENDSWITH'", 
		"'EVENTLOG'", "'FALSE'", "'FIELDS'", "'FROM'", "'H'", "'IN'", "'LIMIT'", 
		"'MAX'", "'MIN'", "'M'", "'MON'", "'NOT'", "'OR'", "'S'", "'SORT'", "'SPAN'", 
		"'STARTSWITH'", "'SEARCH'", "'SUM'", "'TIMETREND'", "'TO'", "'TRUE'", 
		"'W'", "'WHERE'", "'Y'", "'|'", "'='", "';'", "'('", "')'", "'.'", "','", 
		"'<'", "'>'", "'<='", "'>='", "'<>'", "'!='", "':'", "'?'", "'*'", "'+'", 
		"'-'", "'/'", "'%'",
	];
	private static readonly _SYMBOLIC_NAMES: Array<string | undefined> = [
		undefined, "STATS", "ALL", "AND", "AS", "ASC", "AVG", "BETWEEN", "BY", 
		"CONTAINS", "COUNT", "DAY_", "DESC", "DISTINCT", "ENDSWITH", "EVENTLOG", 
		"FALSE", "FIELDS", "FROM", "HOUR_", "IN", "LIMIT", "MAX", "MIN", "MINUTE_", 
		"MONTH_", "NOT", "OR", "SECOND_", "SORT", "SPAN", "STARTSWITH", "SEARCH", 
		"SUM", "TIMETREND", "TO", "TRUE", "WEEK_", "WHERE", "YEAR_", "PIPE", "EQ", 
		"SEMI", "LP", "RP", "DOT", "COMMA", "LT", "GT", "LE", "GE", "NE", "BOX", 
		"COLON", "QM", "STAR", "PLUS", "MINUS", "DIVIDE", "MODULE", "IDENTIFIER", 
		"SQ_STRING_LITERAL", "DQ_STRING_LITERAL", "INTEGRAL_LITERAL", "FLOAT_LITERAL", 
		"REAL_LITERAL", "WS", "LINE_COMMENT",
	];
	public static readonly VOCABULARY: Vocabulary = new VocabularyImpl(EasyParser._LITERAL_NAMES, EasyParser._SYMBOLIC_NAMES, []);

	// @Override
	// @NotNull
	public get vocabulary(): Vocabulary {
		return EasyParser.VOCABULARY;
	}
	// tslint:enable:no-trailing-whitespace

	// @Override
	public get grammarFileName(): string { return "EasyParser.g4"; }

	// @Override
	public get ruleNames(): string[] { return EasyParser.ruleNames; }

	// @Override
	public get serializedATN(): string { return EasyParser._serializedATN; }

	protected createFailedPredicateException(predicate?: string, message?: string): FailedPredicateException {
		return new FailedPredicateException(this, predicate, message);
	}

	constructor(input: TokenStream) {
		super(input);
		this._interp = new ParserATNSimulator(EasyParser._ATN, this);
	}
	// @RuleVersion(0)
	public eql(): EqlContext {
		let _localctx: EqlContext = new EqlContext(this._ctx, this.state);
		this.enterRule(_localctx, 0, EasyParser.RULE_eql);
		let _la: number;
		try {
			this.enterOuterAlt(_localctx, 1);
			{
			this.state = 60;
			this.from_item();
			this.state = 71;
			this._errHandler.sync(this);
			_la = this._input.LA(1);
			while (_la === EasyParser.PIPE) {
				{
				{
				this.state = 61;
				this.match(EasyParser.PIPE);
				this.state = 67;
				this._errHandler.sync(this);
				switch (this._input.LA(1)) {
				case EasyParser.WHERE:
					{
					this.state = 62;
					this.where_operator();
					}
					break;
				case EasyParser.STATS:
					{
					this.state = 63;
					this.aggr_operator();
					}
					break;
				case EasyParser.SORT:
					{
					this.state = 64;
					this.sort_operator();
					}
					break;
				case EasyParser.FIELDS:
					{
					this.state = 65;
					this.fields_operator();
					}
					break;
				case EasyParser.LIMIT:
					{
					this.state = 66;
					this.limit_operator();
					}
					break;
				default:
					throw new NoViableAltException(this);
				}
				}
				}
				this.state = 73;
				this._errHandler.sync(this);
				_la = this._input.LA(1);
			}
			this.state = 74;
			this.match(EasyParser.EOF);
			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				_localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return _localctx;
	}
	// @RuleVersion(0)
	public from_item(): From_itemContext {
		let _localctx: From_itemContext = new From_itemContext(this._ctx, this.state);
		this.enterRule(_localctx, 2, EasyParser.RULE_from_item);
		try {
			this.enterOuterAlt(_localctx, 1);
			{
			this.state = 76;
			this.match(EasyParser.FROM);
			this.state = 77;
			this.table_name();
			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				_localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return _localctx;
	}
	// @RuleVersion(0)
	public where_operator(): Where_operatorContext {
		let _localctx: Where_operatorContext = new Where_operatorContext(this._ctx, this.state);
		this.enterRule(_localctx, 4, EasyParser.RULE_where_operator);
		try {
			this.enterOuterAlt(_localctx, 1);
			{
			this.state = 79;
			this.match(EasyParser.WHERE);
			this.state = 80;
			this.boolean_expression(0);
			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				_localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return _localctx;
	}
	// @RuleVersion(0)
	public aggr_operator(): Aggr_operatorContext {
		let _localctx: Aggr_operatorContext = new Aggr_operatorContext(this._ctx, this.state);
		this.enterRule(_localctx, 6, EasyParser.RULE_aggr_operator);
		let _la: number;
		try {
			this.enterOuterAlt(_localctx, 1);
			{
			this.state = 82;
			this.match(EasyParser.STATS);
			this.state = 83;
			this.aggr_func();
			this.state = 88;
			this._errHandler.sync(this);
			_la = this._input.LA(1);
			while (_la === EasyParser.COMMA) {
				{
				{
				this.state = 84;
				this.match(EasyParser.COMMA);
				this.state = 85;
				this.aggr_func();
				}
				}
				this.state = 90;
				this._errHandler.sync(this);
				_la = this._input.LA(1);
			}
			this.state = 100;
			this._errHandler.sync(this);
			_la = this._input.LA(1);
			if (_la === EasyParser.BY) {
				{
				this.state = 91;
				this.match(EasyParser.BY);
				this.state = 92;
				this.grouping_element();
				this.state = 97;
				this._errHandler.sync(this);
				_la = this._input.LA(1);
				while (_la === EasyParser.COMMA) {
					{
					{
					this.state = 93;
					this.match(EasyParser.COMMA);
					this.state = 94;
					this.grouping_element();
					}
					}
					this.state = 99;
					this._errHandler.sync(this);
					_la = this._input.LA(1);
				}
				}
			}

			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				_localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return _localctx;
	}
	// @RuleVersion(0)
	public sort_operator(): Sort_operatorContext {
		let _localctx: Sort_operatorContext = new Sort_operatorContext(this._ctx, this.state);
		this.enterRule(_localctx, 8, EasyParser.RULE_sort_operator);
		let _la: number;
		try {
			this.enterOuterAlt(_localctx, 1);
			{
			this.state = 102;
			this.match(EasyParser.SORT);
			this.state = 103;
			this.order_item();
			this.state = 108;
			this._errHandler.sync(this);
			_la = this._input.LA(1);
			while (_la === EasyParser.COMMA) {
				{
				{
				this.state = 104;
				this.match(EasyParser.COMMA);
				this.state = 105;
				this.order_item();
				}
				}
				this.state = 110;
				this._errHandler.sync(this);
				_la = this._input.LA(1);
			}
			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				_localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return _localctx;
	}
	// @RuleVersion(0)
	public fields_operator(): Fields_operatorContext {
		let _localctx: Fields_operatorContext = new Fields_operatorContext(this._ctx, this.state);
		this.enterRule(_localctx, 10, EasyParser.RULE_fields_operator);
		let _la: number;
		try {
			this.enterOuterAlt(_localctx, 1);
			{
			this.state = 111;
			this.match(EasyParser.FIELDS);
			this.state = 112;
			this.column();
			this.state = 117;
			this._errHandler.sync(this);
			_la = this._input.LA(1);
			while (_la === EasyParser.COMMA) {
				{
				{
				this.state = 113;
				this.match(EasyParser.COMMA);
				this.state = 114;
				this.column();
				}
				}
				this.state = 119;
				this._errHandler.sync(this);
				_la = this._input.LA(1);
			}
			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				_localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return _localctx;
	}
	// @RuleVersion(0)
	public limit_operator(): Limit_operatorContext {
		let _localctx: Limit_operatorContext = new Limit_operatorContext(this._ctx, this.state);
		this.enterRule(_localctx, 12, EasyParser.RULE_limit_operator);
		try {
			this.enterOuterAlt(_localctx, 1);
			{
			this.state = 120;
			this.match(EasyParser.LIMIT);
			this.state = 121;
			this.int_number();
			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				_localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return _localctx;
	}
	// @RuleVersion(0)
	public grouping_element(): Grouping_elementContext {
		let _localctx: Grouping_elementContext = new Grouping_elementContext(this._ctx, this.state);
		this.enterRule(_localctx, 14, EasyParser.RULE_grouping_element);
		try {
			this.enterOuterAlt(_localctx, 1);
			{
			this.state = 123;
			this.expression(0);
			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				_localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return _localctx;
	}
	// @RuleVersion(0)
	public aggr_func(): Aggr_funcContext {
		let _localctx: Aggr_funcContext = new Aggr_funcContext(this._ctx, this.state);
		this.enterRule(_localctx, 16, EasyParser.RULE_aggr_func);
		let _la: number;
		try {
			this.enterOuterAlt(_localctx, 1);
			{
			this.state = 125;
			this.aggr_expression();
			this.state = 128;
			this._errHandler.sync(this);
			_la = this._input.LA(1);
			if (_la === EasyParser.AS) {
				{
				this.state = 126;
				this.match(EasyParser.AS);
				this.state = 127;
				this.column_alias();
				}
			}

			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				_localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return _localctx;
	}
	// @RuleVersion(0)
	public all_distinct(): All_distinctContext {
		let _localctx: All_distinctContext = new All_distinctContext(this._ctx, this.state);
		this.enterRule(_localctx, 18, EasyParser.RULE_all_distinct);
		let _la: number;
		try {
			this.enterOuterAlt(_localctx, 1);
			{
			this.state = 130;
			_la = this._input.LA(1);
			if (!(_la === EasyParser.ALL || _la === EasyParser.DISTINCT)) {
			this._errHandler.recoverInline(this);
			} else {
				if (this._input.LA(1) === Token.EOF) {
					this.matchedEOF = true;
				}

				this._errHandler.reportMatch(this);
				this.consume();
			}
			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				_localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return _localctx;
	}
	// @RuleVersion(0)
	public order_item(): Order_itemContext {
		let _localctx: Order_itemContext = new Order_itemContext(this._ctx, this.state);
		this.enterRule(_localctx, 20, EasyParser.RULE_order_item);
		let _la: number;
		try {
			this.enterOuterAlt(_localctx, 1);
			{
			this.state = 132;
			this.expression(0);
			this.state = 134;
			this._errHandler.sync(this);
			_la = this._input.LA(1);
			if (_la === EasyParser.ASC || _la === EasyParser.DESC) {
				{
				this.state = 133;
				_la = this._input.LA(1);
				if (!(_la === EasyParser.ASC || _la === EasyParser.DESC)) {
				this._errHandler.recoverInline(this);
				} else {
					if (this._input.LA(1) === Token.EOF) {
						this.matchedEOF = true;
					}

					this._errHandler.reportMatch(this);
					this.consume();
				}
				}
			}

			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				_localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return _localctx;
	}
	// @RuleVersion(0)
	public true_false(): True_falseContext {
		let _localctx: True_falseContext = new True_falseContext(this._ctx, this.state);
		this.enterRule(_localctx, 22, EasyParser.RULE_true_false);
		let _la: number;
		try {
			this.enterOuterAlt(_localctx, 1);
			{
			this.state = 136;
			_la = this._input.LA(1);
			if (!(_la === EasyParser.FALSE || _la === EasyParser.TRUE)) {
			this._errHandler.recoverInline(this);
			} else {
				if (this._input.LA(1) === Token.EOF) {
					this.matchedEOF = true;
				}

				this._errHandler.reportMatch(this);
				this.consume();
			}
			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				_localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return _localctx;
	}

	public boolean_expression(): Boolean_expressionContext;
	public boolean_expression(_p: number): Boolean_expressionContext;
	// @RuleVersion(0)
	public boolean_expression(_p?: number): Boolean_expressionContext {
		if (_p === undefined) {
			_p = 0;
		}

		let _parentctx: ParserRuleContext = this._ctx;
		let _parentState: number = this.state;
		let _localctx: Boolean_expressionContext = new Boolean_expressionContext(this._ctx, _parentState);
		let _prevctx: Boolean_expressionContext = _localctx;
		let _startState: number = 24;
		this.enterRecursionRule(_localctx, 24, EasyParser.RULE_boolean_expression, _p);
		let _la: number;
		try {
			let _alt: number;
			this.enterOuterAlt(_localctx, 1);
			{
			this.state = 153;
			this._errHandler.sync(this);
			switch ( this.interpreter.adaptivePredict(this._input, 11, this._ctx) ) {
			case 1:
				{
				this.state = 142;
				this._errHandler.sync(this);
				_la = this._input.LA(1);
				while (_la === EasyParser.NOT) {
					{
					{
					this.state = 139;
					this.match(EasyParser.NOT);
					}
					}
					this.state = 144;
					this._errHandler.sync(this);
					_la = this._input.LA(1);
				}
				this.state = 150;
				this._errHandler.sync(this);
				switch ( this.interpreter.adaptivePredict(this._input, 10, this._ctx) ) {
				case 1:
					{
					this.state = 145;
					this.match(EasyParser.LP);
					this.state = 146;
					this.boolean_expression(0);
					this.state = 147;
					this.match(EasyParser.RP);
					}
					break;

				case 2:
					{
					this.state = 149;
					this.pred();
					}
					break;
				}
				}
				break;

			case 2:
				{
				this.state = 152;
				this.true_false();
				}
				break;
			}
			this._ctx._stop = this._input.tryLT(-1);
			this.state = 163;
			this._errHandler.sync(this);
			_alt = this.interpreter.adaptivePredict(this._input, 13, this._ctx);
			while (_alt !== 2 && _alt !== ATN.INVALID_ALT_NUMBER) {
				if (_alt === 1) {
					if (this._parseListeners != null) {
						this.triggerExitRuleEvent();
					}
					_prevctx = _localctx;
					{
					this.state = 161;
					this._errHandler.sync(this);
					switch ( this.interpreter.adaptivePredict(this._input, 12, this._ctx) ) {
					case 1:
						{
						_localctx = new Boolean_expressionContext(_parentctx, _parentState);
						this.pushNewRecursionContext(_localctx, _startState, EasyParser.RULE_boolean_expression);
						this.state = 155;
						if (!(this.precpred(this._ctx, 4))) {
							throw this.createFailedPredicateException("this.precpred(this._ctx, 4)");
						}
						this.state = 156;
						this.match(EasyParser.AND);
						this.state = 157;
						this.boolean_expression(5);
						}
						break;

					case 2:
						{
						_localctx = new Boolean_expressionContext(_parentctx, _parentState);
						this.pushNewRecursionContext(_localctx, _startState, EasyParser.RULE_boolean_expression);
						this.state = 158;
						if (!(this.precpred(this._ctx, 3))) {
							throw this.createFailedPredicateException("this.precpred(this._ctx, 3)");
						}
						this.state = 159;
						this.match(EasyParser.OR);
						this.state = 160;
						this.boolean_expression(4);
						}
						break;
					}
					}
				}
				this.state = 165;
				this._errHandler.sync(this);
				_alt = this.interpreter.adaptivePredict(this._input, 13, this._ctx);
			}
			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				_localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.unrollRecursionContexts(_parentctx);
		}
		return _localctx;
	}
	// @RuleVersion(0)
	public pred(): PredContext {
		let _localctx: PredContext = new PredContext(this._ctx, this.state);
		this.enterRule(_localctx, 26, EasyParser.RULE_pred);
		let _la: number;
		try {
			this.state = 192;
			this._errHandler.sync(this);
			switch ( this.interpreter.adaptivePredict(this._input, 16, this._ctx) ) {
			case 1:
				this.enterOuterAlt(_localctx, 1);
				{
				this.state = 166;
				this.expression(0);
				this.state = 167;
				this.comparison_operator();
				this.state = 168;
				this.expression(0);
				}
				break;

			case 2:
				this.enterOuterAlt(_localctx, 2);
				{
				this.state = 170;
				this.expression(0);
				this.state = 171;
				this.match_operator();
				this.state = 172;
				this.string();
				}
				break;

			case 3:
				this.enterOuterAlt(_localctx, 3);
				{
				this.state = 174;
				this.expression(0);
				this.state = 176;
				this._errHandler.sync(this);
				_la = this._input.LA(1);
				if (_la === EasyParser.NOT) {
					{
					this.state = 175;
					this.match(EasyParser.NOT);
					}
				}

				this.state = 178;
				this.match(EasyParser.BETWEEN);
				this.state = 179;
				this.expression(0);
				this.state = 180;
				this.match(EasyParser.AND);
				this.state = 181;
				this.expression(0);
				}
				break;

			case 4:
				this.enterOuterAlt(_localctx, 4);
				{
				this.state = 183;
				this.expression(0);
				this.state = 185;
				this._errHandler.sync(this);
				_la = this._input.LA(1);
				if (_la === EasyParser.NOT) {
					{
					this.state = 184;
					this.match(EasyParser.NOT);
					}
				}

				this.state = 187;
				this.match(EasyParser.IN);
				this.state = 188;
				this.match(EasyParser.LP);
				this.state = 189;
				this.expression_list_();
				this.state = 190;
				this.match(EasyParser.RP);
				}
				break;
			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				_localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return _localctx;
	}
	// @RuleVersion(0)
	public comparison_operator(): Comparison_operatorContext {
		let _localctx: Comparison_operatorContext = new Comparison_operatorContext(this._ctx, this.state);
		this.enterRule(_localctx, 28, EasyParser.RULE_comparison_operator);
		let _la: number;
		try {
			this.enterOuterAlt(_localctx, 1);
			{
			this.state = 194;
			_la = this._input.LA(1);
			if (!(((((_la - 41)) & ~0x1F) === 0 && ((1 << (_la - 41)) & ((1 << (EasyParser.EQ - 41)) | (1 << (EasyParser.LT - 41)) | (1 << (EasyParser.GT - 41)) | (1 << (EasyParser.LE - 41)) | (1 << (EasyParser.GE - 41)) | (1 << (EasyParser.NE - 41)) | (1 << (EasyParser.BOX - 41)))) !== 0))) {
			this._errHandler.recoverInline(this);
			} else {
				if (this._input.LA(1) === Token.EOF) {
					this.matchedEOF = true;
				}

				this._errHandler.reportMatch(this);
				this.consume();
			}
			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				_localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return _localctx;
	}
	// @RuleVersion(0)
	public match_operator(): Match_operatorContext {
		let _localctx: Match_operatorContext = new Match_operatorContext(this._ctx, this.state);
		this.enterRule(_localctx, 30, EasyParser.RULE_match_operator);
		let _la: number;
		try {
			this.enterOuterAlt(_localctx, 1);
			{
			this.state = 196;
			_la = this._input.LA(1);
			if (!((((_la) & ~0x1F) === 0 && ((1 << _la) & ((1 << EasyParser.CONTAINS) | (1 << EasyParser.ENDSWITH) | (1 << EasyParser.STARTSWITH))) !== 0))) {
			this._errHandler.recoverInline(this);
			} else {
				if (this._input.LA(1) === Token.EOF) {
					this.matchedEOF = true;
				}

				this._errHandler.reportMatch(this);
				this.consume();
			}
			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				_localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return _localctx;
	}
	// @RuleVersion(0)
	public expression_list_(): Expression_list_Context {
		let _localctx: Expression_list_Context = new Expression_list_Context(this._ctx, this.state);
		this.enterRule(_localctx, 32, EasyParser.RULE_expression_list_);
		let _la: number;
		try {
			this.enterOuterAlt(_localctx, 1);
			{
			this.state = 198;
			this.expression(0);
			this.state = 203;
			this._errHandler.sync(this);
			_la = this._input.LA(1);
			while (_la === EasyParser.COMMA) {
				{
				{
				this.state = 199;
				this.match(EasyParser.COMMA);
				this.state = 200;
				this.expression(0);
				}
				}
				this.state = 205;
				this._errHandler.sync(this);
				_la = this._input.LA(1);
			}
			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				_localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return _localctx;
	}

	public expression(): ExpressionContext;
	public expression(_p: number): ExpressionContext;
	// @RuleVersion(0)
	public expression(_p?: number): ExpressionContext {
		if (_p === undefined) {
			_p = 0;
		}

		let _parentctx: ParserRuleContext = this._ctx;
		let _parentState: number = this.state;
		let _localctx: ExpressionContext = new ExpressionContext(this._ctx, _parentState);
		let _prevctx: ExpressionContext = _localctx;
		let _startState: number = 34;
		this.enterRecursionRule(_localctx, 34, EasyParser.RULE_expression, _p);
		let _la: number;
		try {
			let _alt: number;
			this.enterOuterAlt(_localctx, 1);
			{
			this.state = 223;
			this._errHandler.sync(this);
			switch ( this.interpreter.adaptivePredict(this._input, 20, this._ctx) ) {
			case 1:
				{
				this.state = 207;
				this.primitive_expression();
				}
				break;

			case 2:
				{
				this.state = 208;
				this.aggr_expression();
				}
				break;

			case 3:
				{
				this.state = 209;
				this.match(EasyParser.LP);
				this.state = 210;
				this.expression(0);
				this.state = 211;
				this.match(EasyParser.RP);
				}
				break;

			case 4:
				{
				this.state = 213;
				this.id_();
				this.state = 214;
				this.match(EasyParser.LP);
				this.state = 216;
				this._errHandler.sync(this);
				_la = this._input.LA(1);
				if (_la === EasyParser.ALL || _la === EasyParser.DISTINCT) {
					{
					this.state = 215;
					this.all_distinct();
					}
				}

				this.state = 219;
				this._errHandler.sync(this);
				_la = this._input.LA(1);
				if (((((_la - 6)) & ~0x1F) === 0 && ((1 << (_la - 6)) & ((1 << (EasyParser.AVG - 6)) | (1 << (EasyParser.COUNT - 6)) | (1 << (EasyParser.FALSE - 6)) | (1 << (EasyParser.MAX - 6)) | (1 << (EasyParser.MIN - 6)) | (1 << (EasyParser.SUM - 6)) | (1 << (EasyParser.TRUE - 6)))) !== 0) || ((((_la - 43)) & ~0x1F) === 0 && ((1 << (_la - 43)) & ((1 << (EasyParser.LP - 43)) | (1 << (EasyParser.IDENTIFIER - 43)) | (1 << (EasyParser.SQ_STRING_LITERAL - 43)) | (1 << (EasyParser.DQ_STRING_LITERAL - 43)) | (1 << (EasyParser.INTEGRAL_LITERAL - 43)) | (1 << (EasyParser.FLOAT_LITERAL - 43)) | (1 << (EasyParser.REAL_LITERAL - 43)))) !== 0)) {
					{
					this.state = 218;
					this.expression_list_();
					}
				}

				this.state = 221;
				this.match(EasyParser.RP);
				}
				break;
			}
			this._ctx._stop = this._input.tryLT(-1);
			this.state = 230;
			this._errHandler.sync(this);
			_alt = this.interpreter.adaptivePredict(this._input, 21, this._ctx);
			while (_alt !== 2 && _alt !== ATN.INVALID_ALT_NUMBER) {
				if (_alt === 1) {
					if (this._parseListeners != null) {
						this.triggerExitRuleEvent();
					}
					_prevctx = _localctx;
					{
					{
					_localctx = new ExpressionContext(_parentctx, _parentState);
					this.pushNewRecursionContext(_localctx, _startState, EasyParser.RULE_expression);
					this.state = 225;
					if (!(this.precpred(this._ctx, 2))) {
						throw this.createFailedPredicateException("this.precpred(this._ctx, 2)");
					}
					this.state = 226;
					_la = this._input.LA(1);
					if (!(((((_la - 55)) & ~0x1F) === 0 && ((1 << (_la - 55)) & ((1 << (EasyParser.STAR - 55)) | (1 << (EasyParser.PLUS - 55)) | (1 << (EasyParser.MINUS - 55)) | (1 << (EasyParser.DIVIDE - 55)) | (1 << (EasyParser.MODULE - 55)))) !== 0))) {
					this._errHandler.recoverInline(this);
					} else {
						if (this._input.LA(1) === Token.EOF) {
							this.matchedEOF = true;
						}

						this._errHandler.reportMatch(this);
						this.consume();
					}
					this.state = 227;
					this.expression(3);
					}
					}
				}
				this.state = 232;
				this._errHandler.sync(this);
				_alt = this.interpreter.adaptivePredict(this._input, 21, this._ctx);
			}
			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				_localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.unrollRecursionContexts(_parentctx);
		}
		return _localctx;
	}
	// @RuleVersion(0)
	public aggr_expression(): Aggr_expressionContext {
		let _localctx: Aggr_expressionContext = new Aggr_expressionContext(this._ctx, this.state);
		this.enterRule(_localctx, 36, EasyParser.RULE_aggr_expression);
		let _la: number;
		try {
			this.state = 255;
			this._errHandler.sync(this);
			switch (this._input.LA(1)) {
			case EasyParser.COUNT:
				this.enterOuterAlt(_localctx, 1);
				{
				this.state = 233;
				this.match(EasyParser.COUNT);
				this.state = 243;
				this._errHandler.sync(this);
				switch ( this.interpreter.adaptivePredict(this._input, 24, this._ctx) ) {
				case 1:
					{
					this.state = 234;
					this.match(EasyParser.LP);
					this.state = 236;
					this._errHandler.sync(this);
					_la = this._input.LA(1);
					if (_la === EasyParser.ALL || _la === EasyParser.DISTINCT) {
						{
						this.state = 235;
						this.all_distinct();
						}
					}

					this.state = 240;
					this._errHandler.sync(this);
					switch (this._input.LA(1)) {
					case EasyParser.AVG:
					case EasyParser.COUNT:
					case EasyParser.FALSE:
					case EasyParser.MAX:
					case EasyParser.MIN:
					case EasyParser.SUM:
					case EasyParser.TRUE:
					case EasyParser.LP:
					case EasyParser.IDENTIFIER:
					case EasyParser.SQ_STRING_LITERAL:
					case EasyParser.DQ_STRING_LITERAL:
					case EasyParser.INTEGRAL_LITERAL:
					case EasyParser.FLOAT_LITERAL:
					case EasyParser.REAL_LITERAL:
						{
						this.state = 238;
						this.expression_list_();
						}
						break;
					case EasyParser.STAR:
						{
						this.state = 239;
						this.match(EasyParser.STAR);
						}
						break;
					case EasyParser.RP:
						break;
					default:
						break;
					}
					this.state = 242;
					this.match(EasyParser.RP);
					}
					break;
				}
				}
				break;
			case EasyParser.AVG:
			case EasyParser.MAX:
			case EasyParser.MIN:
			case EasyParser.SUM:
				this.enterOuterAlt(_localctx, 2);
				{
				this.state = 245;
				_la = this._input.LA(1);
				if (!(((((_la - 6)) & ~0x1F) === 0 && ((1 << (_la - 6)) & ((1 << (EasyParser.AVG - 6)) | (1 << (EasyParser.MAX - 6)) | (1 << (EasyParser.MIN - 6)) | (1 << (EasyParser.SUM - 6)))) !== 0))) {
				this._errHandler.recoverInline(this);
				} else {
					if (this._input.LA(1) === Token.EOF) {
						this.matchedEOF = true;
					}

					this._errHandler.reportMatch(this);
					this.consume();
				}
				this.state = 246;
				this.match(EasyParser.LP);
				this.state = 248;
				this._errHandler.sync(this);
				_la = this._input.LA(1);
				if (_la === EasyParser.ALL || _la === EasyParser.DISTINCT) {
					{
					this.state = 247;
					this.all_distinct();
					}
				}

				this.state = 252;
				this._errHandler.sync(this);
				switch (this._input.LA(1)) {
				case EasyParser.AVG:
				case EasyParser.COUNT:
				case EasyParser.FALSE:
				case EasyParser.MAX:
				case EasyParser.MIN:
				case EasyParser.SUM:
				case EasyParser.TRUE:
				case EasyParser.LP:
				case EasyParser.IDENTIFIER:
				case EasyParser.SQ_STRING_LITERAL:
				case EasyParser.DQ_STRING_LITERAL:
				case EasyParser.INTEGRAL_LITERAL:
				case EasyParser.FLOAT_LITERAL:
				case EasyParser.REAL_LITERAL:
					{
					this.state = 250;
					this.expression_list_();
					}
					break;
				case EasyParser.STAR:
					{
					this.state = 251;
					this.match(EasyParser.STAR);
					}
					break;
				case EasyParser.RP:
					break;
				default:
					break;
				}
				this.state = 254;
				this.match(EasyParser.RP);
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				_localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return _localctx;
	}
	// @RuleVersion(0)
	public primitive_expression(): Primitive_expressionContext {
		let _localctx: Primitive_expressionContext = new Primitive_expressionContext(this._ctx, this.state);
		this.enterRule(_localctx, 38, EasyParser.RULE_primitive_expression);
		try {
			this.state = 259;
			this._errHandler.sync(this);
			switch (this._input.LA(1)) {
			case EasyParser.FALSE:
			case EasyParser.TRUE:
			case EasyParser.SQ_STRING_LITERAL:
			case EasyParser.DQ_STRING_LITERAL:
			case EasyParser.INTEGRAL_LITERAL:
			case EasyParser.FLOAT_LITERAL:
			case EasyParser.REAL_LITERAL:
				this.enterOuterAlt(_localctx, 1);
				{
				this.state = 257;
				this.literal();
				}
				break;
			case EasyParser.IDENTIFIER:
				this.enterOuterAlt(_localctx, 2);
				{
				this.state = 258;
				this.id_();
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				_localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return _localctx;
	}
	// @RuleVersion(0)
	public time_span(): Time_spanContext {
		let _localctx: Time_spanContext = new Time_spanContext(this._ctx, this.state);
		this.enterRule(_localctx, 40, EasyParser.RULE_time_span);
		try {
			this.enterOuterAlt(_localctx, 1);
			{
			this.state = 261;
			this.int_number();
			this.state = 262;
			this.time_interval();
			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				_localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return _localctx;
	}
	// @RuleVersion(0)
	public time_interval(): Time_intervalContext {
		let _localctx: Time_intervalContext = new Time_intervalContext(this._ctx, this.state);
		this.enterRule(_localctx, 42, EasyParser.RULE_time_interval);
		let _la: number;
		try {
			this.enterOuterAlt(_localctx, 1);
			{
			this.state = 264;
			_la = this._input.LA(1);
			if (!(((((_la - 11)) & ~0x1F) === 0 && ((1 << (_la - 11)) & ((1 << (EasyParser.DAY_ - 11)) | (1 << (EasyParser.HOUR_ - 11)) | (1 << (EasyParser.MINUTE_ - 11)) | (1 << (EasyParser.MONTH_ - 11)) | (1 << (EasyParser.SECOND_ - 11)) | (1 << (EasyParser.WEEK_ - 11)) | (1 << (EasyParser.YEAR_ - 11)))) !== 0))) {
			this._errHandler.recoverInline(this);
			} else {
				if (this._input.LA(1) === Token.EOF) {
					this.matchedEOF = true;
				}

				this._errHandler.reportMatch(this);
				this.consume();
			}
			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				_localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return _localctx;
	}
	// @RuleVersion(0)
	public literal(): LiteralContext {
		let _localctx: LiteralContext = new LiteralContext(this._ctx, this.state);
		this.enterRule(_localctx, 44, EasyParser.RULE_literal);
		try {
			this.state = 269;
			this._errHandler.sync(this);
			switch (this._input.LA(1)) {
			case EasyParser.INTEGRAL_LITERAL:
			case EasyParser.FLOAT_LITERAL:
			case EasyParser.REAL_LITERAL:
				this.enterOuterAlt(_localctx, 1);
				{
				this.state = 266;
				this.number();
				}
				break;
			case EasyParser.SQ_STRING_LITERAL:
			case EasyParser.DQ_STRING_LITERAL:
				this.enterOuterAlt(_localctx, 2);
				{
				this.state = 267;
				this.string();
				}
				break;
			case EasyParser.FALSE:
			case EasyParser.TRUE:
				this.enterOuterAlt(_localctx, 3);
				{
				this.state = 268;
				this.true_false();
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				_localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return _localctx;
	}
	// @RuleVersion(0)
	public int_number(): Int_numberContext {
		let _localctx: Int_numberContext = new Int_numberContext(this._ctx, this.state);
		this.enterRule(_localctx, 46, EasyParser.RULE_int_number);
		try {
			this.enterOuterAlt(_localctx, 1);
			{
			this.state = 271;
			this.match(EasyParser.INTEGRAL_LITERAL);
			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				_localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return _localctx;
	}
	// @RuleVersion(0)
	public number(): NumberContext {
		let _localctx: NumberContext = new NumberContext(this._ctx, this.state);
		this.enterRule(_localctx, 48, EasyParser.RULE_number);
		try {
			this.state = 276;
			this._errHandler.sync(this);
			switch (this._input.LA(1)) {
			case EasyParser.INTEGRAL_LITERAL:
				this.enterOuterAlt(_localctx, 1);
				{
				this.state = 273;
				this.int_number();
				}
				break;
			case EasyParser.REAL_LITERAL:
				this.enterOuterAlt(_localctx, 2);
				{
				this.state = 274;
				this.match(EasyParser.REAL_LITERAL);
				}
				break;
			case EasyParser.FLOAT_LITERAL:
				this.enterOuterAlt(_localctx, 3);
				{
				this.state = 275;
				this.match(EasyParser.FLOAT_LITERAL);
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				_localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return _localctx;
	}
	// @RuleVersion(0)
	public table_name(): Table_nameContext {
		let _localctx: Table_nameContext = new Table_nameContext(this._ctx, this.state);
		this.enterRule(_localctx, 50, EasyParser.RULE_table_name);
		try {
			this.enterOuterAlt(_localctx, 1);
			{
			this.state = 278;
			this.match(EasyParser.IDENTIFIER);
			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				_localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return _localctx;
	}
	// @RuleVersion(0)
	public column_alias(): Column_aliasContext {
		let _localctx: Column_aliasContext = new Column_aliasContext(this._ctx, this.state);
		this.enterRule(_localctx, 52, EasyParser.RULE_column_alias);
		try {
			this.enterOuterAlt(_localctx, 1);
			{
			this.state = 280;
			this.id_();
			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				_localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return _localctx;
	}
	// @RuleVersion(0)
	public column(): ColumnContext {
		let _localctx: ColumnContext = new ColumnContext(this._ctx, this.state);
		this.enterRule(_localctx, 54, EasyParser.RULE_column);
		let _la: number;
		try {
			this.enterOuterAlt(_localctx, 1);
			{
			this.state = 282;
			this.expression(0);
			this.state = 285;
			this._errHandler.sync(this);
			_la = this._input.LA(1);
			if (_la === EasyParser.AS) {
				{
				this.state = 283;
				this.match(EasyParser.AS);
				this.state = 284;
				this.column_alias();
				}
			}

			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				_localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return _localctx;
	}
	// @RuleVersion(0)
	public string(): StringContext {
		let _localctx: StringContext = new StringContext(this._ctx, this.state);
		this.enterRule(_localctx, 56, EasyParser.RULE_string);
		let _la: number;
		try {
			this.enterOuterAlt(_localctx, 1);
			{
			this.state = 287;
			_la = this._input.LA(1);
			if (!(_la === EasyParser.SQ_STRING_LITERAL || _la === EasyParser.DQ_STRING_LITERAL)) {
			this._errHandler.recoverInline(this);
			} else {
				if (this._input.LA(1) === Token.EOF) {
					this.matchedEOF = true;
				}

				this._errHandler.reportMatch(this);
				this.consume();
			}
			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				_localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return _localctx;
	}
	// @RuleVersion(0)
	public id_(): Id_Context {
		let _localctx: Id_Context = new Id_Context(this._ctx, this.state);
		this.enterRule(_localctx, 58, EasyParser.RULE_id_);
		try {
			this.enterOuterAlt(_localctx, 1);
			{
			this.state = 289;
			this.match(EasyParser.IDENTIFIER);
			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				_localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return _localctx;
	}

	public sempred(_localctx: RuleContext, ruleIndex: number, predIndex: number): boolean {
		switch (ruleIndex) {
		case 12:
			return this.boolean_expression_sempred(_localctx as Boolean_expressionContext, predIndex);

		case 17:
			return this.expression_sempred(_localctx as ExpressionContext, predIndex);
		}
		return true;
	}
	private boolean_expression_sempred(_localctx: Boolean_expressionContext, predIndex: number): boolean {
		switch (predIndex) {
		case 0:
			return this.precpred(this._ctx, 4);

		case 1:
			return this.precpred(this._ctx, 3);
		}
		return true;
	}
	private expression_sempred(_localctx: ExpressionContext, predIndex: number): boolean {
		switch (predIndex) {
		case 2:
			return this.precpred(this._ctx, 2);
		}
		return true;
	}

	public static readonly _serializedATN: string =
		"\x03\uC91D\uCABA\u058D\uAFBA\u4F53\u0607\uEA8B\uC241\x03E\u0126\x04\x02" +
		"\t\x02\x04\x03\t\x03\x04\x04\t\x04\x04\x05\t\x05\x04\x06\t\x06\x04\x07" +
		"\t\x07\x04\b\t\b\x04\t\t\t\x04\n\t\n\x04\v\t\v\x04\f\t\f\x04\r\t\r\x04" +
		"\x0E\t\x0E\x04\x0F\t\x0F\x04\x10\t\x10\x04\x11\t\x11\x04\x12\t\x12\x04" +
		"\x13\t\x13\x04\x14\t\x14\x04\x15\t\x15\x04\x16\t\x16\x04\x17\t\x17\x04" +
		"\x18\t\x18\x04\x19\t\x19\x04\x1A\t\x1A\x04\x1B\t\x1B\x04\x1C\t\x1C\x04" +
		"\x1D\t\x1D\x04\x1E\t\x1E\x04\x1F\t\x1F\x03\x02\x03\x02\x03\x02\x03\x02" +
		"\x03\x02\x03\x02\x03\x02\x05\x02F\n\x02\x07\x02H\n\x02\f\x02\x0E\x02K" +
		"\v\x02\x03\x02\x03\x02\x03\x03\x03\x03\x03\x03\x03\x04\x03\x04\x03\x04" +
		"\x03\x05\x03\x05\x03\x05\x03\x05\x07\x05Y\n\x05\f\x05\x0E\x05\\\v\x05" +
		"\x03\x05\x03\x05\x03\x05\x03\x05\x07\x05b\n\x05\f\x05\x0E\x05e\v\x05\x05" +
		"\x05g\n\x05\x03\x06\x03\x06\x03\x06\x03\x06\x07\x06m\n\x06\f\x06\x0E\x06" +
		"p\v\x06\x03\x07\x03\x07\x03\x07\x03\x07\x07\x07v\n\x07\f\x07\x0E\x07y" +
		"\v\x07\x03\b\x03\b\x03\b\x03\t\x03\t\x03\n\x03\n\x03\n\x05\n\x83\n\n\x03" +
		"\v\x03\v\x03\f\x03\f\x05\f\x89\n\f\x03\r\x03\r\x03\x0E\x03\x0E\x07\x0E" +
		"\x8F\n\x0E\f\x0E\x0E\x0E\x92\v\x0E\x03\x0E\x03\x0E\x03\x0E\x03\x0E\x03" +
		"\x0E\x05\x0E\x99\n\x0E\x03\x0E\x05\x0E\x9C\n\x0E\x03\x0E\x03\x0E\x03\x0E" +
		"\x03\x0E\x03\x0E\x03\x0E\x07\x0E\xA4\n\x0E\f\x0E\x0E\x0E\xA7\v\x0E\x03" +
		"\x0F\x03\x0F\x03\x0F\x03\x0F\x03\x0F\x03\x0F\x03\x0F\x03\x0F\x03\x0F\x03" +
		"\x0F\x05\x0F\xB3\n\x0F\x03\x0F\x03\x0F\x03\x0F\x03\x0F\x03\x0F\x03\x0F" +
		"\x03\x0F\x05\x0F\xBC\n\x0F\x03\x0F\x03\x0F\x03\x0F\x03\x0F\x03\x0F\x05" +
		"\x0F\xC3\n\x0F\x03\x10\x03\x10\x03\x11\x03\x11\x03\x12\x03\x12\x03\x12" +
		"\x07\x12\xCC\n\x12\f\x12\x0E\x12\xCF\v\x12\x03\x13\x03\x13\x03\x13\x03" +
		"\x13\x03\x13\x03\x13\x03\x13\x03\x13\x03\x13\x03\x13\x05\x13\xDB\n\x13" +
		"\x03\x13\x05\x13\xDE\n\x13\x03\x13\x03\x13\x05\x13\xE2\n\x13\x03\x13\x03" +
		"\x13\x03\x13\x07\x13\xE7\n\x13\f\x13\x0E\x13\xEA\v\x13\x03\x14\x03\x14" +
		"\x03\x14\x05\x14\xEF\n\x14\x03\x14\x03\x14\x05\x14\xF3\n\x14\x03\x14\x05" +
		"\x14\xF6\n\x14\x03\x14\x03\x14\x03\x14\x05\x14\xFB\n\x14\x03\x14\x03\x14" +
		"\x05\x14\xFF\n\x14\x03\x14\x05\x14\u0102\n\x14\x03\x15\x03\x15\x05\x15" +
		"\u0106\n\x15\x03\x16\x03\x16\x03\x16\x03\x17\x03\x17\x03\x18\x03\x18\x03" +
		"\x18\x05\x18\u0110\n\x18\x03\x19\x03\x19\x03\x1A\x03\x1A\x03\x1A\x05\x1A" +
		"\u0117\n\x1A\x03\x1B\x03\x1B\x03\x1C\x03\x1C\x03\x1D\x03\x1D\x03\x1D\x05" +
		"\x1D\u0120\n\x1D\x03\x1E\x03\x1E\x03\x1F\x03\x1F\x03\x1F\x02\x02\x04\x1A" +
		"$ \x02\x02\x04\x02\x06\x02\b\x02\n\x02\f\x02\x0E\x02\x10\x02\x12\x02\x14" +
		"\x02\x16\x02\x18\x02\x1A\x02\x1C\x02\x1E\x02 \x02\"\x02$\x02&\x02(\x02" +
		"*\x02,\x02.\x020\x022\x024\x026\x028\x02:\x02<\x02\x02\v\x04\x02\x04\x04" +
		"\x0F\x0F\x04\x02\x07\x07\x0E\x0E\x04\x02\x12\x12&&\x04\x02++16\x05\x02" +
		"\v\v\x10\x10!!\x03\x029=\x05\x02\b\b\x18\x19##\b\x02\r\r\x15\x15\x1A\x1B" +
		"\x1E\x1E\'\'))\x03\x02?@\x02\u0132\x02>\x03\x02\x02\x02\x04N\x03\x02\x02" +
		"\x02\x06Q\x03\x02\x02\x02\bT\x03\x02\x02\x02\nh\x03\x02\x02\x02\fq\x03" +
		"\x02\x02\x02\x0Ez\x03\x02\x02\x02\x10}\x03\x02\x02\x02\x12\x7F\x03\x02" +
		"\x02\x02\x14\x84\x03\x02\x02\x02\x16\x86\x03\x02\x02\x02\x18\x8A\x03\x02" +
		"\x02\x02\x1A\x9B\x03\x02\x02\x02\x1C\xC2\x03\x02\x02\x02\x1E\xC4\x03\x02" +
		"\x02\x02 \xC6\x03\x02\x02\x02\"\xC8\x03\x02\x02\x02$\xE1\x03\x02\x02\x02" +
		"&\u0101\x03\x02\x02\x02(\u0105\x03\x02\x02\x02*\u0107\x03\x02\x02\x02" +
		",\u010A\x03\x02\x02\x02.\u010F\x03\x02\x02\x020\u0111\x03\x02\x02\x02" +
		"2\u0116\x03\x02\x02\x024\u0118\x03\x02\x02\x026\u011A\x03\x02\x02\x02" +
		"8\u011C\x03\x02\x02\x02:\u0121\x03\x02\x02\x02<\u0123\x03\x02\x02\x02" +
		">I\x05\x04\x03\x02?E\x07*\x02\x02@F\x05\x06\x04\x02AF\x05\b\x05\x02BF" +
		"\x05\n\x06\x02CF\x05\f\x07\x02DF\x05\x0E\b\x02E@\x03\x02\x02\x02EA\x03" +
		"\x02\x02\x02EB\x03\x02\x02\x02EC\x03\x02\x02\x02ED\x03\x02\x02\x02FH\x03" +
		"\x02\x02\x02G?\x03\x02\x02\x02HK\x03\x02\x02\x02IG\x03\x02\x02\x02IJ\x03" +
		"\x02\x02\x02JL\x03\x02\x02\x02KI\x03\x02\x02\x02LM\x07\x02\x02\x03M\x03" +
		"\x03\x02\x02\x02NO\x07\x14\x02\x02OP\x054\x1B\x02P\x05\x03\x02\x02\x02" +
		"QR\x07(\x02\x02RS\x05\x1A\x0E\x02S\x07\x03\x02\x02\x02TU\x07\x03\x02\x02" +
		"UZ\x05\x12\n\x02VW\x070\x02\x02WY\x05\x12\n\x02XV\x03\x02\x02\x02Y\\\x03" +
		"\x02\x02\x02ZX\x03\x02\x02\x02Z[\x03\x02\x02\x02[f\x03\x02\x02\x02\\Z" +
		"\x03\x02\x02\x02]^\x07\n\x02\x02^c\x05\x10\t\x02_`\x070\x02\x02`b\x05" +
		"\x10\t\x02a_\x03\x02\x02\x02be\x03\x02\x02\x02ca\x03\x02\x02\x02cd\x03" +
		"\x02\x02\x02dg\x03\x02\x02\x02ec\x03\x02\x02\x02f]\x03\x02\x02\x02fg\x03" +
		"\x02\x02\x02g\t\x03\x02\x02\x02hi\x07\x1F\x02\x02in\x05\x16\f\x02jk\x07" +
		"0\x02\x02km\x05\x16\f\x02lj\x03\x02\x02\x02mp\x03\x02\x02\x02nl\x03\x02" +
		"\x02\x02no\x03\x02\x02\x02o\v\x03\x02\x02\x02pn\x03\x02\x02\x02qr\x07" +
		"\x13\x02\x02rw\x058\x1D\x02st\x070\x02\x02tv\x058\x1D\x02us\x03\x02\x02" +
		"\x02vy\x03\x02\x02\x02wu\x03\x02\x02\x02wx\x03\x02\x02\x02x\r\x03\x02" +
		"\x02\x02yw\x03\x02\x02\x02z{\x07\x17\x02\x02{|\x050\x19\x02|\x0F\x03\x02" +
		"\x02\x02}~\x05$\x13\x02~\x11\x03\x02\x02\x02\x7F\x82\x05&\x14\x02\x80" +
		"\x81\x07\x06\x02\x02\x81\x83\x056\x1C\x02\x82\x80\x03\x02\x02\x02\x82" +
		"\x83\x03\x02\x02\x02\x83\x13\x03\x02\x02\x02\x84\x85\t\x02\x02\x02\x85" +
		"\x15\x03\x02\x02\x02\x86\x88\x05$\x13\x02\x87\x89\t\x03\x02\x02\x88\x87" +
		"\x03\x02\x02\x02\x88\x89\x03\x02\x02\x02\x89\x17\x03\x02\x02\x02\x8A\x8B" +
		"\t\x04\x02\x02\x8B\x19\x03\x02\x02\x02\x8C\x90\b\x0E\x01\x02\x8D\x8F\x07" +
		"\x1C\x02\x02\x8E\x8D\x03\x02\x02\x02\x8F\x92\x03\x02\x02\x02\x90\x8E\x03" +
		"\x02\x02\x02\x90\x91\x03\x02\x02\x02\x91\x98\x03\x02\x02\x02\x92\x90\x03" +
		"\x02\x02\x02\x93\x94\x07-\x02\x02\x94\x95\x05\x1A\x0E\x02\x95\x96\x07" +
		".\x02\x02\x96\x99\x03\x02\x02\x02\x97\x99\x05\x1C\x0F\x02\x98\x93\x03" +
		"\x02\x02\x02\x98\x97\x03\x02\x02\x02\x99\x9C\x03\x02\x02\x02\x9A\x9C\x05" +
		"\x18\r\x02\x9B\x8C\x03\x02\x02\x02\x9B\x9A\x03\x02\x02\x02\x9C\xA5\x03" +
		"\x02\x02\x02\x9D\x9E\f\x06\x02\x02\x9E\x9F\x07\x05\x02\x02\x9F\xA4\x05" +
		"\x1A\x0E\x07\xA0\xA1\f\x05\x02\x02\xA1\xA2\x07\x1D\x02\x02\xA2\xA4\x05" +
		"\x1A\x0E\x06\xA3\x9D\x03\x02\x02\x02\xA3\xA0\x03\x02\x02\x02\xA4\xA7\x03" +
		"\x02\x02\x02\xA5\xA3\x03\x02\x02\x02\xA5\xA6\x03\x02\x02\x02\xA6\x1B\x03" +
		"\x02\x02\x02\xA7\xA5\x03\x02\x02\x02\xA8\xA9\x05$\x13\x02\xA9\xAA\x05" +
		"\x1E\x10\x02\xAA\xAB\x05$\x13\x02\xAB\xC3\x03\x02\x02\x02\xAC\xAD\x05" +
		"$\x13\x02\xAD\xAE\x05 \x11\x02\xAE\xAF\x05:\x1E\x02\xAF\xC3\x03\x02\x02" +
		"\x02\xB0\xB2\x05$\x13\x02\xB1\xB3\x07\x1C\x02\x02\xB2\xB1\x03\x02\x02" +
		"\x02\xB2\xB3\x03\x02\x02\x02\xB3\xB4\x03\x02\x02\x02\xB4\xB5\x07\t\x02" +
		"\x02\xB5\xB6\x05$\x13\x02\xB6\xB7\x07\x05\x02\x02\xB7\xB8\x05$\x13\x02" +
		"\xB8\xC3\x03\x02\x02\x02\xB9\xBB\x05$\x13\x02\xBA\xBC\x07\x1C\x02\x02" +
		"\xBB\xBA\x03\x02\x02\x02\xBB\xBC\x03\x02\x02\x02\xBC\xBD\x03\x02\x02\x02" +
		"\xBD\xBE\x07\x16\x02\x02\xBE\xBF\x07-\x02\x02\xBF\xC0\x05\"\x12\x02\xC0" +
		"\xC1\x07.\x02\x02\xC1\xC3\x03\x02\x02\x02\xC2\xA8\x03\x02\x02\x02\xC2" +
		"\xAC\x03\x02\x02\x02\xC2\xB0\x03\x02\x02\x02\xC2\xB9\x03\x02\x02\x02\xC3" +
		"\x1D\x03\x02\x02\x02\xC4\xC5\t\x05\x02\x02\xC5\x1F\x03\x02\x02\x02\xC6" +
		"\xC7\t\x06\x02\x02\xC7!\x03\x02\x02\x02\xC8\xCD\x05$\x13\x02\xC9\xCA\x07" +
		"0\x02\x02\xCA\xCC\x05$\x13\x02\xCB\xC9\x03\x02\x02\x02\xCC\xCF\x03\x02" +
		"\x02\x02\xCD\xCB\x03\x02\x02\x02\xCD\xCE\x03\x02\x02\x02\xCE#\x03\x02" +
		"\x02\x02\xCF\xCD\x03\x02\x02\x02\xD0\xD1\b\x13\x01\x02\xD1\xE2\x05(\x15" +
		"\x02\xD2\xE2\x05&\x14\x02\xD3\xD4\x07-\x02\x02\xD4\xD5\x05$\x13\x02\xD5" +
		"\xD6\x07.\x02\x02\xD6\xE2\x03\x02\x02\x02\xD7\xD8\x05<\x1F\x02\xD8\xDA" +
		"\x07-\x02\x02\xD9\xDB\x05\x14\v\x02\xDA\xD9\x03\x02\x02\x02\xDA\xDB\x03" +
		"\x02\x02\x02\xDB\xDD\x03\x02\x02\x02\xDC\xDE\x05\"\x12\x02\xDD\xDC\x03" +
		"\x02\x02\x02\xDD\xDE\x03\x02\x02\x02\xDE\xDF\x03\x02\x02\x02\xDF\xE0\x07" +
		".\x02\x02\xE0\xE2\x03\x02\x02\x02\xE1\xD0\x03\x02\x02\x02\xE1\xD2\x03" +
		"\x02\x02\x02\xE1\xD3\x03\x02\x02\x02\xE1\xD7\x03\x02\x02\x02\xE2\xE8\x03" +
		"\x02\x02\x02\xE3\xE4\f\x04\x02\x02\xE4\xE5\t\x07\x02\x02\xE5\xE7\x05$" +
		"\x13\x05\xE6\xE3\x03\x02\x02\x02\xE7\xEA\x03\x02\x02\x02\xE8\xE6\x03\x02" +
		"\x02\x02\xE8\xE9\x03\x02\x02\x02\xE9%\x03\x02\x02\x02\xEA\xE8\x03\x02" +
		"\x02\x02\xEB\xF5\x07\f\x02\x02\xEC\xEE\x07-\x02\x02\xED\xEF\x05\x14\v" +
		"\x02\xEE\xED\x03\x02\x02\x02\xEE\xEF\x03\x02\x02\x02\xEF\xF2\x03\x02\x02" +
		"\x02\xF0\xF3\x05\"\x12\x02\xF1\xF3\x079\x02\x02\xF2\xF0\x03\x02\x02\x02" +
		"\xF2\xF1\x03\x02\x02\x02\xF2\xF3\x03\x02\x02\x02\xF3\xF4\x03\x02\x02\x02" +
		"\xF4\xF6\x07.\x02\x02\xF5\xEC\x03\x02\x02\x02\xF5\xF6\x03\x02\x02\x02" +
		"\xF6\u0102\x03\x02\x02\x02\xF7\xF8\t\b\x02\x02\xF8\xFA\x07-\x02\x02\xF9" +
		"\xFB\x05\x14\v\x02\xFA\xF9\x03\x02\x02\x02\xFA\xFB\x03\x02\x02\x02\xFB" +
		"\xFE\x03\x02\x02\x02\xFC\xFF\x05\"\x12\x02\xFD\xFF\x079\x02\x02\xFE\xFC" +
		"\x03\x02\x02\x02\xFE\xFD\x03\x02\x02\x02\xFE\xFF\x03\x02\x02\x02\xFF\u0100" +
		"\x03\x02\x02\x02\u0100\u0102\x07.\x02\x02\u0101\xEB\x03\x02\x02\x02\u0101" +
		"\xF7\x03\x02\x02\x02\u0102\'\x03\x02\x02\x02\u0103\u0106\x05.\x18\x02" +
		"\u0104\u0106\x05<\x1F\x02\u0105\u0103\x03\x02\x02\x02\u0105\u0104\x03" +
		"\x02\x02\x02\u0106)\x03\x02\x02\x02\u0107\u0108\x050\x19\x02\u0108\u0109" +
		"\x05,\x17\x02\u0109+\x03\x02\x02\x02\u010A\u010B\t\t\x02\x02\u010B-\x03" +
		"\x02\x02\x02\u010C\u0110\x052\x1A\x02\u010D\u0110\x05:\x1E\x02\u010E\u0110" +
		"\x05\x18\r\x02\u010F\u010C\x03\x02\x02\x02\u010F\u010D\x03\x02\x02\x02" +
		"\u010F\u010E\x03\x02\x02\x02\u0110/\x03\x02\x02\x02\u0111\u0112\x07A\x02" +
		"\x02\u01121\x03\x02\x02\x02\u0113\u0117\x050\x19\x02\u0114\u0117\x07C" +
		"\x02\x02\u0115\u0117\x07B\x02\x02\u0116\u0113\x03\x02\x02\x02\u0116\u0114" +
		"\x03\x02\x02\x02\u0116\u0115\x03\x02\x02\x02\u01173\x03\x02\x02\x02\u0118" +
		"\u0119\x07>\x02\x02\u01195\x03\x02\x02\x02\u011A\u011B\x05<\x1F\x02\u011B" +
		"7\x03\x02\x02\x02\u011C\u011F\x05$\x13\x02\u011D\u011E\x07\x06\x02\x02" +
		"\u011E\u0120\x056\x1C\x02\u011F\u011D\x03\x02\x02\x02\u011F\u0120\x03" +
		"\x02\x02\x02\u01209\x03\x02\x02\x02\u0121\u0122\t\n\x02\x02\u0122;\x03" +
		"\x02\x02\x02\u0123\u0124\x07>\x02\x02\u0124=\x03\x02\x02\x02\"EIZcfnw" +
		"\x82\x88\x90\x98\x9B\xA3\xA5\xB2\xBB\xC2\xCD\xDA\xDD\xE1\xE8\xEE\xF2\xF5" +
		"\xFA\xFE\u0101\u0105\u010F\u0116\u011F";
	public static __ATN: ATN;
	public static get _ATN(): ATN {
		if (!EasyParser.__ATN) {
			EasyParser.__ATN = new ATNDeserializer().deserialize(Utils.toCharArray(EasyParser._serializedATN));
		}

		return EasyParser.__ATN;
	}

}

export class EqlContext extends ParserRuleContext {
	public from_item(): From_itemContext {
		return this.getRuleContext(0, From_itemContext);
	}
	public EOF(): TerminalNode { return this.getToken(EasyParser.EOF, 0); }
	public PIPE(): TerminalNode[];
	public PIPE(i: number): TerminalNode;
	public PIPE(i?: number): TerminalNode | TerminalNode[] {
		if (i === undefined) {
			return this.getTokens(EasyParser.PIPE);
		} else {
			return this.getToken(EasyParser.PIPE, i);
		}
	}
	public where_operator(): Where_operatorContext[];
	public where_operator(i: number): Where_operatorContext;
	public where_operator(i?: number): Where_operatorContext | Where_operatorContext[] {
		if (i === undefined) {
			return this.getRuleContexts(Where_operatorContext);
		} else {
			return this.getRuleContext(i, Where_operatorContext);
		}
	}
	public aggr_operator(): Aggr_operatorContext[];
	public aggr_operator(i: number): Aggr_operatorContext;
	public aggr_operator(i?: number): Aggr_operatorContext | Aggr_operatorContext[] {
		if (i === undefined) {
			return this.getRuleContexts(Aggr_operatorContext);
		} else {
			return this.getRuleContext(i, Aggr_operatorContext);
		}
	}
	public sort_operator(): Sort_operatorContext[];
	public sort_operator(i: number): Sort_operatorContext;
	public sort_operator(i?: number): Sort_operatorContext | Sort_operatorContext[] {
		if (i === undefined) {
			return this.getRuleContexts(Sort_operatorContext);
		} else {
			return this.getRuleContext(i, Sort_operatorContext);
		}
	}
	public fields_operator(): Fields_operatorContext[];
	public fields_operator(i: number): Fields_operatorContext;
	public fields_operator(i?: number): Fields_operatorContext | Fields_operatorContext[] {
		if (i === undefined) {
			return this.getRuleContexts(Fields_operatorContext);
		} else {
			return this.getRuleContext(i, Fields_operatorContext);
		}
	}
	public limit_operator(): Limit_operatorContext[];
	public limit_operator(i: number): Limit_operatorContext;
	public limit_operator(i?: number): Limit_operatorContext | Limit_operatorContext[] {
		if (i === undefined) {
			return this.getRuleContexts(Limit_operatorContext);
		} else {
			return this.getRuleContext(i, Limit_operatorContext);
		}
	}
	constructor(parent: ParserRuleContext | undefined, invokingState: number) {
		super(parent, invokingState);
	}
	// @Override
	public get ruleIndex(): number { return EasyParser.RULE_eql; }
	// @Override
	public enterRule(listener: EasyParserListener): void {
		if (listener.enterEql) {
			listener.enterEql(this);
		}
	}
	// @Override
	public exitRule(listener: EasyParserListener): void {
		if (listener.exitEql) {
			listener.exitEql(this);
		}
	}
	// @Override
	public accept<Result>(visitor: EasyParserVisitor<Result>): Result {
		if (visitor.visitEql) {
			return visitor.visitEql(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class From_itemContext extends ParserRuleContext {
	public FROM(): TerminalNode { return this.getToken(EasyParser.FROM, 0); }
	public table_name(): Table_nameContext {
		return this.getRuleContext(0, Table_nameContext);
	}
	constructor(parent: ParserRuleContext | undefined, invokingState: number) {
		super(parent, invokingState);
	}
	// @Override
	public get ruleIndex(): number { return EasyParser.RULE_from_item; }
	// @Override
	public enterRule(listener: EasyParserListener): void {
		if (listener.enterFrom_item) {
			listener.enterFrom_item(this);
		}
	}
	// @Override
	public exitRule(listener: EasyParserListener): void {
		if (listener.exitFrom_item) {
			listener.exitFrom_item(this);
		}
	}
	// @Override
	public accept<Result>(visitor: EasyParserVisitor<Result>): Result {
		if (visitor.visitFrom_item) {
			return visitor.visitFrom_item(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class Where_operatorContext extends ParserRuleContext {
	public WHERE(): TerminalNode { return this.getToken(EasyParser.WHERE, 0); }
	public boolean_expression(): Boolean_expressionContext {
		return this.getRuleContext(0, Boolean_expressionContext);
	}
	constructor(parent: ParserRuleContext | undefined, invokingState: number) {
		super(parent, invokingState);
	}
	// @Override
	public get ruleIndex(): number { return EasyParser.RULE_where_operator; }
	// @Override
	public enterRule(listener: EasyParserListener): void {
		if (listener.enterWhere_operator) {
			listener.enterWhere_operator(this);
		}
	}
	// @Override
	public exitRule(listener: EasyParserListener): void {
		if (listener.exitWhere_operator) {
			listener.exitWhere_operator(this);
		}
	}
	// @Override
	public accept<Result>(visitor: EasyParserVisitor<Result>): Result {
		if (visitor.visitWhere_operator) {
			return visitor.visitWhere_operator(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class Aggr_operatorContext extends ParserRuleContext {
	public STATS(): TerminalNode { return this.getToken(EasyParser.STATS, 0); }
	public aggr_func(): Aggr_funcContext[];
	public aggr_func(i: number): Aggr_funcContext;
	public aggr_func(i?: number): Aggr_funcContext | Aggr_funcContext[] {
		if (i === undefined) {
			return this.getRuleContexts(Aggr_funcContext);
		} else {
			return this.getRuleContext(i, Aggr_funcContext);
		}
	}
	public COMMA(): TerminalNode[];
	public COMMA(i: number): TerminalNode;
	public COMMA(i?: number): TerminalNode | TerminalNode[] {
		if (i === undefined) {
			return this.getTokens(EasyParser.COMMA);
		} else {
			return this.getToken(EasyParser.COMMA, i);
		}
	}
	public BY(): TerminalNode | undefined { return this.tryGetToken(EasyParser.BY, 0); }
	public grouping_element(): Grouping_elementContext[];
	public grouping_element(i: number): Grouping_elementContext;
	public grouping_element(i?: number): Grouping_elementContext | Grouping_elementContext[] {
		if (i === undefined) {
			return this.getRuleContexts(Grouping_elementContext);
		} else {
			return this.getRuleContext(i, Grouping_elementContext);
		}
	}
	constructor(parent: ParserRuleContext | undefined, invokingState: number) {
		super(parent, invokingState);
	}
	// @Override
	public get ruleIndex(): number { return EasyParser.RULE_aggr_operator; }
	// @Override
	public enterRule(listener: EasyParserListener): void {
		if (listener.enterAggr_operator) {
			listener.enterAggr_operator(this);
		}
	}
	// @Override
	public exitRule(listener: EasyParserListener): void {
		if (listener.exitAggr_operator) {
			listener.exitAggr_operator(this);
		}
	}
	// @Override
	public accept<Result>(visitor: EasyParserVisitor<Result>): Result {
		if (visitor.visitAggr_operator) {
			return visitor.visitAggr_operator(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class Sort_operatorContext extends ParserRuleContext {
	public SORT(): TerminalNode { return this.getToken(EasyParser.SORT, 0); }
	public order_item(): Order_itemContext[];
	public order_item(i: number): Order_itemContext;
	public order_item(i?: number): Order_itemContext | Order_itemContext[] {
		if (i === undefined) {
			return this.getRuleContexts(Order_itemContext);
		} else {
			return this.getRuleContext(i, Order_itemContext);
		}
	}
	public COMMA(): TerminalNode[];
	public COMMA(i: number): TerminalNode;
	public COMMA(i?: number): TerminalNode | TerminalNode[] {
		if (i === undefined) {
			return this.getTokens(EasyParser.COMMA);
		} else {
			return this.getToken(EasyParser.COMMA, i);
		}
	}
	constructor(parent: ParserRuleContext | undefined, invokingState: number) {
		super(parent, invokingState);
	}
	// @Override
	public get ruleIndex(): number { return EasyParser.RULE_sort_operator; }
	// @Override
	public enterRule(listener: EasyParserListener): void {
		if (listener.enterSort_operator) {
			listener.enterSort_operator(this);
		}
	}
	// @Override
	public exitRule(listener: EasyParserListener): void {
		if (listener.exitSort_operator) {
			listener.exitSort_operator(this);
		}
	}
	// @Override
	public accept<Result>(visitor: EasyParserVisitor<Result>): Result {
		if (visitor.visitSort_operator) {
			return visitor.visitSort_operator(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class Fields_operatorContext extends ParserRuleContext {
	public FIELDS(): TerminalNode { return this.getToken(EasyParser.FIELDS, 0); }
	public column(): ColumnContext[];
	public column(i: number): ColumnContext;
	public column(i?: number): ColumnContext | ColumnContext[] {
		if (i === undefined) {
			return this.getRuleContexts(ColumnContext);
		} else {
			return this.getRuleContext(i, ColumnContext);
		}
	}
	public COMMA(): TerminalNode[];
	public COMMA(i: number): TerminalNode;
	public COMMA(i?: number): TerminalNode | TerminalNode[] {
		if (i === undefined) {
			return this.getTokens(EasyParser.COMMA);
		} else {
			return this.getToken(EasyParser.COMMA, i);
		}
	}
	constructor(parent: ParserRuleContext | undefined, invokingState: number) {
		super(parent, invokingState);
	}
	// @Override
	public get ruleIndex(): number { return EasyParser.RULE_fields_operator; }
	// @Override
	public enterRule(listener: EasyParserListener): void {
		if (listener.enterFields_operator) {
			listener.enterFields_operator(this);
		}
	}
	// @Override
	public exitRule(listener: EasyParserListener): void {
		if (listener.exitFields_operator) {
			listener.exitFields_operator(this);
		}
	}
	// @Override
	public accept<Result>(visitor: EasyParserVisitor<Result>): Result {
		if (visitor.visitFields_operator) {
			return visitor.visitFields_operator(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class Limit_operatorContext extends ParserRuleContext {
	public LIMIT(): TerminalNode { return this.getToken(EasyParser.LIMIT, 0); }
	public int_number(): Int_numberContext {
		return this.getRuleContext(0, Int_numberContext);
	}
	constructor(parent: ParserRuleContext | undefined, invokingState: number) {
		super(parent, invokingState);
	}
	// @Override
	public get ruleIndex(): number { return EasyParser.RULE_limit_operator; }
	// @Override
	public enterRule(listener: EasyParserListener): void {
		if (listener.enterLimit_operator) {
			listener.enterLimit_operator(this);
		}
	}
	// @Override
	public exitRule(listener: EasyParserListener): void {
		if (listener.exitLimit_operator) {
			listener.exitLimit_operator(this);
		}
	}
	// @Override
	public accept<Result>(visitor: EasyParserVisitor<Result>): Result {
		if (visitor.visitLimit_operator) {
			return visitor.visitLimit_operator(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class Grouping_elementContext extends ParserRuleContext {
	public expression(): ExpressionContext {
		return this.getRuleContext(0, ExpressionContext);
	}
	constructor(parent: ParserRuleContext | undefined, invokingState: number) {
		super(parent, invokingState);
	}
	// @Override
	public get ruleIndex(): number { return EasyParser.RULE_grouping_element; }
	// @Override
	public enterRule(listener: EasyParserListener): void {
		if (listener.enterGrouping_element) {
			listener.enterGrouping_element(this);
		}
	}
	// @Override
	public exitRule(listener: EasyParserListener): void {
		if (listener.exitGrouping_element) {
			listener.exitGrouping_element(this);
		}
	}
	// @Override
	public accept<Result>(visitor: EasyParserVisitor<Result>): Result {
		if (visitor.visitGrouping_element) {
			return visitor.visitGrouping_element(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class Aggr_funcContext extends ParserRuleContext {
	public aggr_expression(): Aggr_expressionContext {
		return this.getRuleContext(0, Aggr_expressionContext);
	}
	public AS(): TerminalNode | undefined { return this.tryGetToken(EasyParser.AS, 0); }
	public column_alias(): Column_aliasContext | undefined {
		return this.tryGetRuleContext(0, Column_aliasContext);
	}
	constructor(parent: ParserRuleContext | undefined, invokingState: number) {
		super(parent, invokingState);
	}
	// @Override
	public get ruleIndex(): number { return EasyParser.RULE_aggr_func; }
	// @Override
	public enterRule(listener: EasyParserListener): void {
		if (listener.enterAggr_func) {
			listener.enterAggr_func(this);
		}
	}
	// @Override
	public exitRule(listener: EasyParserListener): void {
		if (listener.exitAggr_func) {
			listener.exitAggr_func(this);
		}
	}
	// @Override
	public accept<Result>(visitor: EasyParserVisitor<Result>): Result {
		if (visitor.visitAggr_func) {
			return visitor.visitAggr_func(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class All_distinctContext extends ParserRuleContext {
	public ALL(): TerminalNode | undefined { return this.tryGetToken(EasyParser.ALL, 0); }
	public DISTINCT(): TerminalNode | undefined { return this.tryGetToken(EasyParser.DISTINCT, 0); }
	constructor(parent: ParserRuleContext | undefined, invokingState: number) {
		super(parent, invokingState);
	}
	// @Override
	public get ruleIndex(): number { return EasyParser.RULE_all_distinct; }
	// @Override
	public enterRule(listener: EasyParserListener): void {
		if (listener.enterAll_distinct) {
			listener.enterAll_distinct(this);
		}
	}
	// @Override
	public exitRule(listener: EasyParserListener): void {
		if (listener.exitAll_distinct) {
			listener.exitAll_distinct(this);
		}
	}
	// @Override
	public accept<Result>(visitor: EasyParserVisitor<Result>): Result {
		if (visitor.visitAll_distinct) {
			return visitor.visitAll_distinct(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class Order_itemContext extends ParserRuleContext {
	public expression(): ExpressionContext {
		return this.getRuleContext(0, ExpressionContext);
	}
	public ASC(): TerminalNode | undefined { return this.tryGetToken(EasyParser.ASC, 0); }
	public DESC(): TerminalNode | undefined { return this.tryGetToken(EasyParser.DESC, 0); }
	constructor(parent: ParserRuleContext | undefined, invokingState: number) {
		super(parent, invokingState);
	}
	// @Override
	public get ruleIndex(): number { return EasyParser.RULE_order_item; }
	// @Override
	public enterRule(listener: EasyParserListener): void {
		if (listener.enterOrder_item) {
			listener.enterOrder_item(this);
		}
	}
	// @Override
	public exitRule(listener: EasyParserListener): void {
		if (listener.exitOrder_item) {
			listener.exitOrder_item(this);
		}
	}
	// @Override
	public accept<Result>(visitor: EasyParserVisitor<Result>): Result {
		if (visitor.visitOrder_item) {
			return visitor.visitOrder_item(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class True_falseContext extends ParserRuleContext {
	public TRUE(): TerminalNode | undefined { return this.tryGetToken(EasyParser.TRUE, 0); }
	public FALSE(): TerminalNode | undefined { return this.tryGetToken(EasyParser.FALSE, 0); }
	constructor(parent: ParserRuleContext | undefined, invokingState: number) {
		super(parent, invokingState);
	}
	// @Override
	public get ruleIndex(): number { return EasyParser.RULE_true_false; }
	// @Override
	public enterRule(listener: EasyParserListener): void {
		if (listener.enterTrue_false) {
			listener.enterTrue_false(this);
		}
	}
	// @Override
	public exitRule(listener: EasyParserListener): void {
		if (listener.exitTrue_false) {
			listener.exitTrue_false(this);
		}
	}
	// @Override
	public accept<Result>(visitor: EasyParserVisitor<Result>): Result {
		if (visitor.visitTrue_false) {
			return visitor.visitTrue_false(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class Boolean_expressionContext extends ParserRuleContext {
	public boolean_expression(): Boolean_expressionContext[];
	public boolean_expression(i: number): Boolean_expressionContext;
	public boolean_expression(i?: number): Boolean_expressionContext | Boolean_expressionContext[] {
		if (i === undefined) {
			return this.getRuleContexts(Boolean_expressionContext);
		} else {
			return this.getRuleContext(i, Boolean_expressionContext);
		}
	}
	public AND(): TerminalNode | undefined { return this.tryGetToken(EasyParser.AND, 0); }
	public OR(): TerminalNode | undefined { return this.tryGetToken(EasyParser.OR, 0); }
	public LP(): TerminalNode | undefined { return this.tryGetToken(EasyParser.LP, 0); }
	public RP(): TerminalNode | undefined { return this.tryGetToken(EasyParser.RP, 0); }
	public pred(): PredContext | undefined {
		return this.tryGetRuleContext(0, PredContext);
	}
	public NOT(): TerminalNode[];
	public NOT(i: number): TerminalNode;
	public NOT(i?: number): TerminalNode | TerminalNode[] {
		if (i === undefined) {
			return this.getTokens(EasyParser.NOT);
		} else {
			return this.getToken(EasyParser.NOT, i);
		}
	}
	public true_false(): True_falseContext | undefined {
		return this.tryGetRuleContext(0, True_falseContext);
	}
	constructor(parent: ParserRuleContext | undefined, invokingState: number) {
		super(parent, invokingState);
	}
	// @Override
	public get ruleIndex(): number { return EasyParser.RULE_boolean_expression; }
	// @Override
	public enterRule(listener: EasyParserListener): void {
		if (listener.enterBoolean_expression) {
			listener.enterBoolean_expression(this);
		}
	}
	// @Override
	public exitRule(listener: EasyParserListener): void {
		if (listener.exitBoolean_expression) {
			listener.exitBoolean_expression(this);
		}
	}
	// @Override
	public accept<Result>(visitor: EasyParserVisitor<Result>): Result {
		if (visitor.visitBoolean_expression) {
			return visitor.visitBoolean_expression(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class PredContext extends ParserRuleContext {
	public expression(): ExpressionContext[];
	public expression(i: number): ExpressionContext;
	public expression(i?: number): ExpressionContext | ExpressionContext[] {
		if (i === undefined) {
			return this.getRuleContexts(ExpressionContext);
		} else {
			return this.getRuleContext(i, ExpressionContext);
		}
	}
	public comparison_operator(): Comparison_operatorContext | undefined {
		return this.tryGetRuleContext(0, Comparison_operatorContext);
	}
	public match_operator(): Match_operatorContext | undefined {
		return this.tryGetRuleContext(0, Match_operatorContext);
	}
	public string(): StringContext | undefined {
		return this.tryGetRuleContext(0, StringContext);
	}
	public BETWEEN(): TerminalNode | undefined { return this.tryGetToken(EasyParser.BETWEEN, 0); }
	public AND(): TerminalNode | undefined { return this.tryGetToken(EasyParser.AND, 0); }
	public NOT(): TerminalNode | undefined { return this.tryGetToken(EasyParser.NOT, 0); }
	public IN(): TerminalNode | undefined { return this.tryGetToken(EasyParser.IN, 0); }
	public LP(): TerminalNode | undefined { return this.tryGetToken(EasyParser.LP, 0); }
	public expression_list_(): Expression_list_Context | undefined {
		return this.tryGetRuleContext(0, Expression_list_Context);
	}
	public RP(): TerminalNode | undefined { return this.tryGetToken(EasyParser.RP, 0); }
	constructor(parent: ParserRuleContext | undefined, invokingState: number) {
		super(parent, invokingState);
	}
	// @Override
	public get ruleIndex(): number { return EasyParser.RULE_pred; }
	// @Override
	public enterRule(listener: EasyParserListener): void {
		if (listener.enterPred) {
			listener.enterPred(this);
		}
	}
	// @Override
	public exitRule(listener: EasyParserListener): void {
		if (listener.exitPred) {
			listener.exitPred(this);
		}
	}
	// @Override
	public accept<Result>(visitor: EasyParserVisitor<Result>): Result {
		if (visitor.visitPred) {
			return visitor.visitPred(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class Comparison_operatorContext extends ParserRuleContext {
	public LT(): TerminalNode | undefined { return this.tryGetToken(EasyParser.LT, 0); }
	public EQ(): TerminalNode | undefined { return this.tryGetToken(EasyParser.EQ, 0); }
	public GT(): TerminalNode | undefined { return this.tryGetToken(EasyParser.GT, 0); }
	public LE(): TerminalNode | undefined { return this.tryGetToken(EasyParser.LE, 0); }
	public GE(): TerminalNode | undefined { return this.tryGetToken(EasyParser.GE, 0); }
	public NE(): TerminalNode | undefined { return this.tryGetToken(EasyParser.NE, 0); }
	public BOX(): TerminalNode | undefined { return this.tryGetToken(EasyParser.BOX, 0); }
	constructor(parent: ParserRuleContext | undefined, invokingState: number) {
		super(parent, invokingState);
	}
	// @Override
	public get ruleIndex(): number { return EasyParser.RULE_comparison_operator; }
	// @Override
	public enterRule(listener: EasyParserListener): void {
		if (listener.enterComparison_operator) {
			listener.enterComparison_operator(this);
		}
	}
	// @Override
	public exitRule(listener: EasyParserListener): void {
		if (listener.exitComparison_operator) {
			listener.exitComparison_operator(this);
		}
	}
	// @Override
	public accept<Result>(visitor: EasyParserVisitor<Result>): Result {
		if (visitor.visitComparison_operator) {
			return visitor.visitComparison_operator(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class Match_operatorContext extends ParserRuleContext {
	public CONTAINS(): TerminalNode | undefined { return this.tryGetToken(EasyParser.CONTAINS, 0); }
	public STARTSWITH(): TerminalNode | undefined { return this.tryGetToken(EasyParser.STARTSWITH, 0); }
	public ENDSWITH(): TerminalNode | undefined { return this.tryGetToken(EasyParser.ENDSWITH, 0); }
	constructor(parent: ParserRuleContext | undefined, invokingState: number) {
		super(parent, invokingState);
	}
	// @Override
	public get ruleIndex(): number { return EasyParser.RULE_match_operator; }
	// @Override
	public enterRule(listener: EasyParserListener): void {
		if (listener.enterMatch_operator) {
			listener.enterMatch_operator(this);
		}
	}
	// @Override
	public exitRule(listener: EasyParserListener): void {
		if (listener.exitMatch_operator) {
			listener.exitMatch_operator(this);
		}
	}
	// @Override
	public accept<Result>(visitor: EasyParserVisitor<Result>): Result {
		if (visitor.visitMatch_operator) {
			return visitor.visitMatch_operator(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class Expression_list_Context extends ParserRuleContext {
	public expression(): ExpressionContext[];
	public expression(i: number): ExpressionContext;
	public expression(i?: number): ExpressionContext | ExpressionContext[] {
		if (i === undefined) {
			return this.getRuleContexts(ExpressionContext);
		} else {
			return this.getRuleContext(i, ExpressionContext);
		}
	}
	public COMMA(): TerminalNode[];
	public COMMA(i: number): TerminalNode;
	public COMMA(i?: number): TerminalNode | TerminalNode[] {
		if (i === undefined) {
			return this.getTokens(EasyParser.COMMA);
		} else {
			return this.getToken(EasyParser.COMMA, i);
		}
	}
	constructor(parent: ParserRuleContext | undefined, invokingState: number) {
		super(parent, invokingState);
	}
	// @Override
	public get ruleIndex(): number { return EasyParser.RULE_expression_list_; }
	// @Override
	public enterRule(listener: EasyParserListener): void {
		if (listener.enterExpression_list_) {
			listener.enterExpression_list_(this);
		}
	}
	// @Override
	public exitRule(listener: EasyParserListener): void {
		if (listener.exitExpression_list_) {
			listener.exitExpression_list_(this);
		}
	}
	// @Override
	public accept<Result>(visitor: EasyParserVisitor<Result>): Result {
		if (visitor.visitExpression_list_) {
			return visitor.visitExpression_list_(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class ExpressionContext extends ParserRuleContext {
	public primitive_expression(): Primitive_expressionContext | undefined {
		return this.tryGetRuleContext(0, Primitive_expressionContext);
	}
	public aggr_expression(): Aggr_expressionContext | undefined {
		return this.tryGetRuleContext(0, Aggr_expressionContext);
	}
	public LP(): TerminalNode | undefined { return this.tryGetToken(EasyParser.LP, 0); }
	public expression(): ExpressionContext[];
	public expression(i: number): ExpressionContext;
	public expression(i?: number): ExpressionContext | ExpressionContext[] {
		if (i === undefined) {
			return this.getRuleContexts(ExpressionContext);
		} else {
			return this.getRuleContext(i, ExpressionContext);
		}
	}
	public RP(): TerminalNode | undefined { return this.tryGetToken(EasyParser.RP, 0); }
	public PLUS(): TerminalNode | undefined { return this.tryGetToken(EasyParser.PLUS, 0); }
	public MINUS(): TerminalNode | undefined { return this.tryGetToken(EasyParser.MINUS, 0); }
	public STAR(): TerminalNode | undefined { return this.tryGetToken(EasyParser.STAR, 0); }
	public DIVIDE(): TerminalNode | undefined { return this.tryGetToken(EasyParser.DIVIDE, 0); }
	public MODULE(): TerminalNode | undefined { return this.tryGetToken(EasyParser.MODULE, 0); }
	public id_(): Id_Context | undefined {
		return this.tryGetRuleContext(0, Id_Context);
	}
	public all_distinct(): All_distinctContext | undefined {
		return this.tryGetRuleContext(0, All_distinctContext);
	}
	public expression_list_(): Expression_list_Context | undefined {
		return this.tryGetRuleContext(0, Expression_list_Context);
	}
	constructor(parent: ParserRuleContext | undefined, invokingState: number) {
		super(parent, invokingState);
	}
	// @Override
	public get ruleIndex(): number { return EasyParser.RULE_expression; }
	// @Override
	public enterRule(listener: EasyParserListener): void {
		if (listener.enterExpression) {
			listener.enterExpression(this);
		}
	}
	// @Override
	public exitRule(listener: EasyParserListener): void {
		if (listener.exitExpression) {
			listener.exitExpression(this);
		}
	}
	// @Override
	public accept<Result>(visitor: EasyParserVisitor<Result>): Result {
		if (visitor.visitExpression) {
			return visitor.visitExpression(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class Aggr_expressionContext extends ParserRuleContext {
	public COUNT(): TerminalNode | undefined { return this.tryGetToken(EasyParser.COUNT, 0); }
	public LP(): TerminalNode | undefined { return this.tryGetToken(EasyParser.LP, 0); }
	public RP(): TerminalNode | undefined { return this.tryGetToken(EasyParser.RP, 0); }
	public all_distinct(): All_distinctContext | undefined {
		return this.tryGetRuleContext(0, All_distinctContext);
	}
	public expression_list_(): Expression_list_Context | undefined {
		return this.tryGetRuleContext(0, Expression_list_Context);
	}
	public STAR(): TerminalNode | undefined { return this.tryGetToken(EasyParser.STAR, 0); }
	public AVG(): TerminalNode | undefined { return this.tryGetToken(EasyParser.AVG, 0); }
	public MIN(): TerminalNode | undefined { return this.tryGetToken(EasyParser.MIN, 0); }
	public MAX(): TerminalNode | undefined { return this.tryGetToken(EasyParser.MAX, 0); }
	public SUM(): TerminalNode | undefined { return this.tryGetToken(EasyParser.SUM, 0); }
	constructor(parent: ParserRuleContext | undefined, invokingState: number) {
		super(parent, invokingState);
	}
	// @Override
	public get ruleIndex(): number { return EasyParser.RULE_aggr_expression; }
	// @Override
	public enterRule(listener: EasyParserListener): void {
		if (listener.enterAggr_expression) {
			listener.enterAggr_expression(this);
		}
	}
	// @Override
	public exitRule(listener: EasyParserListener): void {
		if (listener.exitAggr_expression) {
			listener.exitAggr_expression(this);
		}
	}
	// @Override
	public accept<Result>(visitor: EasyParserVisitor<Result>): Result {
		if (visitor.visitAggr_expression) {
			return visitor.visitAggr_expression(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class Primitive_expressionContext extends ParserRuleContext {
	public literal(): LiteralContext | undefined {
		return this.tryGetRuleContext(0, LiteralContext);
	}
	public id_(): Id_Context | undefined {
		return this.tryGetRuleContext(0, Id_Context);
	}
	constructor(parent: ParserRuleContext | undefined, invokingState: number) {
		super(parent, invokingState);
	}
	// @Override
	public get ruleIndex(): number { return EasyParser.RULE_primitive_expression; }
	// @Override
	public enterRule(listener: EasyParserListener): void {
		if (listener.enterPrimitive_expression) {
			listener.enterPrimitive_expression(this);
		}
	}
	// @Override
	public exitRule(listener: EasyParserListener): void {
		if (listener.exitPrimitive_expression) {
			listener.exitPrimitive_expression(this);
		}
	}
	// @Override
	public accept<Result>(visitor: EasyParserVisitor<Result>): Result {
		if (visitor.visitPrimitive_expression) {
			return visitor.visitPrimitive_expression(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class Time_spanContext extends ParserRuleContext {
	public int_number(): Int_numberContext {
		return this.getRuleContext(0, Int_numberContext);
	}
	public time_interval(): Time_intervalContext {
		return this.getRuleContext(0, Time_intervalContext);
	}
	constructor(parent: ParserRuleContext | undefined, invokingState: number) {
		super(parent, invokingState);
	}
	// @Override
	public get ruleIndex(): number { return EasyParser.RULE_time_span; }
	// @Override
	public enterRule(listener: EasyParserListener): void {
		if (listener.enterTime_span) {
			listener.enterTime_span(this);
		}
	}
	// @Override
	public exitRule(listener: EasyParserListener): void {
		if (listener.exitTime_span) {
			listener.exitTime_span(this);
		}
	}
	// @Override
	public accept<Result>(visitor: EasyParserVisitor<Result>): Result {
		if (visitor.visitTime_span) {
			return visitor.visitTime_span(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class Time_intervalContext extends ParserRuleContext {
	public SECOND_(): TerminalNode | undefined { return this.tryGetToken(EasyParser.SECOND_, 0); }
	public MINUTE_(): TerminalNode | undefined { return this.tryGetToken(EasyParser.MINUTE_, 0); }
	public HOUR_(): TerminalNode | undefined { return this.tryGetToken(EasyParser.HOUR_, 0); }
	public DAY_(): TerminalNode | undefined { return this.tryGetToken(EasyParser.DAY_, 0); }
	public WEEK_(): TerminalNode | undefined { return this.tryGetToken(EasyParser.WEEK_, 0); }
	public MONTH_(): TerminalNode | undefined { return this.tryGetToken(EasyParser.MONTH_, 0); }
	public YEAR_(): TerminalNode | undefined { return this.tryGetToken(EasyParser.YEAR_, 0); }
	constructor(parent: ParserRuleContext | undefined, invokingState: number) {
		super(parent, invokingState);
	}
	// @Override
	public get ruleIndex(): number { return EasyParser.RULE_time_interval; }
	// @Override
	public enterRule(listener: EasyParserListener): void {
		if (listener.enterTime_interval) {
			listener.enterTime_interval(this);
		}
	}
	// @Override
	public exitRule(listener: EasyParserListener): void {
		if (listener.exitTime_interval) {
			listener.exitTime_interval(this);
		}
	}
	// @Override
	public accept<Result>(visitor: EasyParserVisitor<Result>): Result {
		if (visitor.visitTime_interval) {
			return visitor.visitTime_interval(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class LiteralContext extends ParserRuleContext {
	public number(): NumberContext | undefined {
		return this.tryGetRuleContext(0, NumberContext);
	}
	public string(): StringContext | undefined {
		return this.tryGetRuleContext(0, StringContext);
	}
	public true_false(): True_falseContext | undefined {
		return this.tryGetRuleContext(0, True_falseContext);
	}
	constructor(parent: ParserRuleContext | undefined, invokingState: number) {
		super(parent, invokingState);
	}
	// @Override
	public get ruleIndex(): number { return EasyParser.RULE_literal; }
	// @Override
	public enterRule(listener: EasyParserListener): void {
		if (listener.enterLiteral) {
			listener.enterLiteral(this);
		}
	}
	// @Override
	public exitRule(listener: EasyParserListener): void {
		if (listener.exitLiteral) {
			listener.exitLiteral(this);
		}
	}
	// @Override
	public accept<Result>(visitor: EasyParserVisitor<Result>): Result {
		if (visitor.visitLiteral) {
			return visitor.visitLiteral(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class Int_numberContext extends ParserRuleContext {
	public INTEGRAL_LITERAL(): TerminalNode { return this.getToken(EasyParser.INTEGRAL_LITERAL, 0); }
	constructor(parent: ParserRuleContext | undefined, invokingState: number) {
		super(parent, invokingState);
	}
	// @Override
	public get ruleIndex(): number { return EasyParser.RULE_int_number; }
	// @Override
	public enterRule(listener: EasyParserListener): void {
		if (listener.enterInt_number) {
			listener.enterInt_number(this);
		}
	}
	// @Override
	public exitRule(listener: EasyParserListener): void {
		if (listener.exitInt_number) {
			listener.exitInt_number(this);
		}
	}
	// @Override
	public accept<Result>(visitor: EasyParserVisitor<Result>): Result {
		if (visitor.visitInt_number) {
			return visitor.visitInt_number(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class NumberContext extends ParserRuleContext {
	public int_number(): Int_numberContext | undefined {
		return this.tryGetRuleContext(0, Int_numberContext);
	}
	public REAL_LITERAL(): TerminalNode | undefined { return this.tryGetToken(EasyParser.REAL_LITERAL, 0); }
	public FLOAT_LITERAL(): TerminalNode | undefined { return this.tryGetToken(EasyParser.FLOAT_LITERAL, 0); }
	constructor(parent: ParserRuleContext | undefined, invokingState: number) {
		super(parent, invokingState);
	}
	// @Override
	public get ruleIndex(): number { return EasyParser.RULE_number; }
	// @Override
	public enterRule(listener: EasyParserListener): void {
		if (listener.enterNumber) {
			listener.enterNumber(this);
		}
	}
	// @Override
	public exitRule(listener: EasyParserListener): void {
		if (listener.exitNumber) {
			listener.exitNumber(this);
		}
	}
	// @Override
	public accept<Result>(visitor: EasyParserVisitor<Result>): Result {
		if (visitor.visitNumber) {
			return visitor.visitNumber(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class Table_nameContext extends ParserRuleContext {
	public IDENTIFIER(): TerminalNode { return this.getToken(EasyParser.IDENTIFIER, 0); }
	constructor(parent: ParserRuleContext | undefined, invokingState: number) {
		super(parent, invokingState);
	}
	// @Override
	public get ruleIndex(): number { return EasyParser.RULE_table_name; }
	// @Override
	public enterRule(listener: EasyParserListener): void {
		if (listener.enterTable_name) {
			listener.enterTable_name(this);
		}
	}
	// @Override
	public exitRule(listener: EasyParserListener): void {
		if (listener.exitTable_name) {
			listener.exitTable_name(this);
		}
	}
	// @Override
	public accept<Result>(visitor: EasyParserVisitor<Result>): Result {
		if (visitor.visitTable_name) {
			return visitor.visitTable_name(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class Column_aliasContext extends ParserRuleContext {
	public id_(): Id_Context {
		return this.getRuleContext(0, Id_Context);
	}
	constructor(parent: ParserRuleContext | undefined, invokingState: number) {
		super(parent, invokingState);
	}
	// @Override
	public get ruleIndex(): number { return EasyParser.RULE_column_alias; }
	// @Override
	public enterRule(listener: EasyParserListener): void {
		if (listener.enterColumn_alias) {
			listener.enterColumn_alias(this);
		}
	}
	// @Override
	public exitRule(listener: EasyParserListener): void {
		if (listener.exitColumn_alias) {
			listener.exitColumn_alias(this);
		}
	}
	// @Override
	public accept<Result>(visitor: EasyParserVisitor<Result>): Result {
		if (visitor.visitColumn_alias) {
			return visitor.visitColumn_alias(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class ColumnContext extends ParserRuleContext {
	public expression(): ExpressionContext {
		return this.getRuleContext(0, ExpressionContext);
	}
	public AS(): TerminalNode | undefined { return this.tryGetToken(EasyParser.AS, 0); }
	public column_alias(): Column_aliasContext | undefined {
		return this.tryGetRuleContext(0, Column_aliasContext);
	}
	constructor(parent: ParserRuleContext | undefined, invokingState: number) {
		super(parent, invokingState);
	}
	// @Override
	public get ruleIndex(): number { return EasyParser.RULE_column; }
	// @Override
	public enterRule(listener: EasyParserListener): void {
		if (listener.enterColumn) {
			listener.enterColumn(this);
		}
	}
	// @Override
	public exitRule(listener: EasyParserListener): void {
		if (listener.exitColumn) {
			listener.exitColumn(this);
		}
	}
	// @Override
	public accept<Result>(visitor: EasyParserVisitor<Result>): Result {
		if (visitor.visitColumn) {
			return visitor.visitColumn(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class StringContext extends ParserRuleContext {
	public DQ_STRING_LITERAL(): TerminalNode | undefined { return this.tryGetToken(EasyParser.DQ_STRING_LITERAL, 0); }
	public SQ_STRING_LITERAL(): TerminalNode | undefined { return this.tryGetToken(EasyParser.SQ_STRING_LITERAL, 0); }
	constructor(parent: ParserRuleContext | undefined, invokingState: number) {
		super(parent, invokingState);
	}
	// @Override
	public get ruleIndex(): number { return EasyParser.RULE_string; }
	// @Override
	public enterRule(listener: EasyParserListener): void {
		if (listener.enterString) {
			listener.enterString(this);
		}
	}
	// @Override
	public exitRule(listener: EasyParserListener): void {
		if (listener.exitString) {
			listener.exitString(this);
		}
	}
	// @Override
	public accept<Result>(visitor: EasyParserVisitor<Result>): Result {
		if (visitor.visitString) {
			return visitor.visitString(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class Id_Context extends ParserRuleContext {
	public IDENTIFIER(): TerminalNode { return this.getToken(EasyParser.IDENTIFIER, 0); }
	constructor(parent: ParserRuleContext | undefined, invokingState: number) {
		super(parent, invokingState);
	}
	// @Override
	public get ruleIndex(): number { return EasyParser.RULE_id_; }
	// @Override
	public enterRule(listener: EasyParserListener): void {
		if (listener.enterId_) {
			listener.enterId_(this);
		}
	}
	// @Override
	public exitRule(listener: EasyParserListener): void {
		if (listener.exitId_) {
			listener.exitId_(this);
		}
	}
	// @Override
	public accept<Result>(visitor: EasyParserVisitor<Result>): Result {
		if (visitor.visitId_) {
			return visitor.visitId_(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


