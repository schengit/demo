// Generated from grammar/EasyParser.g4 by ANTLR 4.9.0-SNAPSHOT


import { ParseTreeVisitor } from "antlr4ts/tree/ParseTreeVisitor";

import { EqlContext } from "./EasyParser";
import { From_itemContext } from "./EasyParser";
import { Where_operatorContext } from "./EasyParser";
import { Aggr_operatorContext } from "./EasyParser";
import { Sort_operatorContext } from "./EasyParser";
import { Fields_operatorContext } from "./EasyParser";
import { Limit_operatorContext } from "./EasyParser";
import { Grouping_elementContext } from "./EasyParser";
import { Aggr_funcContext } from "./EasyParser";
import { All_distinctContext } from "./EasyParser";
import { Order_itemContext } from "./EasyParser";
import { True_falseContext } from "./EasyParser";
import { Boolean_expressionContext } from "./EasyParser";
import { PredContext } from "./EasyParser";
import { Comparison_operatorContext } from "./EasyParser";
import { Match_operatorContext } from "./EasyParser";
import { Expression_list_Context } from "./EasyParser";
import { ExpressionContext } from "./EasyParser";
import { Aggr_expressionContext } from "./EasyParser";
import { Primitive_expressionContext } from "./EasyParser";
import { Time_spanContext } from "./EasyParser";
import { Time_intervalContext } from "./EasyParser";
import { LiteralContext } from "./EasyParser";
import { Int_numberContext } from "./EasyParser";
import { NumberContext } from "./EasyParser";
import { Table_nameContext } from "./EasyParser";
import { Column_aliasContext } from "./EasyParser";
import { ColumnContext } from "./EasyParser";
import { StringContext } from "./EasyParser";
import { Id_Context } from "./EasyParser";


/**
 * This interface defines a complete generic visitor for a parse tree produced
 * by `EasyParser`.
 *
 * @param <Result> The return type of the visit operation. Use `void` for
 * operations with no return type.
 */
export interface EasyParserVisitor<Result> extends ParseTreeVisitor<Result> {
	/**
	 * Visit a parse tree produced by `EasyParser.eql`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitEql?: (ctx: EqlContext) => Result;

	/**
	 * Visit a parse tree produced by `EasyParser.from_item`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitFrom_item?: (ctx: From_itemContext) => Result;

	/**
	 * Visit a parse tree produced by `EasyParser.where_operator`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitWhere_operator?: (ctx: Where_operatorContext) => Result;

	/**
	 * Visit a parse tree produced by `EasyParser.aggr_operator`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitAggr_operator?: (ctx: Aggr_operatorContext) => Result;

	/**
	 * Visit a parse tree produced by `EasyParser.sort_operator`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitSort_operator?: (ctx: Sort_operatorContext) => Result;

	/**
	 * Visit a parse tree produced by `EasyParser.fields_operator`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitFields_operator?: (ctx: Fields_operatorContext) => Result;

	/**
	 * Visit a parse tree produced by `EasyParser.limit_operator`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitLimit_operator?: (ctx: Limit_operatorContext) => Result;

	/**
	 * Visit a parse tree produced by `EasyParser.grouping_element`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitGrouping_element?: (ctx: Grouping_elementContext) => Result;

	/**
	 * Visit a parse tree produced by `EasyParser.aggr_func`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitAggr_func?: (ctx: Aggr_funcContext) => Result;

	/**
	 * Visit a parse tree produced by `EasyParser.all_distinct`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitAll_distinct?: (ctx: All_distinctContext) => Result;

	/**
	 * Visit a parse tree produced by `EasyParser.order_item`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitOrder_item?: (ctx: Order_itemContext) => Result;

	/**
	 * Visit a parse tree produced by `EasyParser.true_false`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitTrue_false?: (ctx: True_falseContext) => Result;

	/**
	 * Visit a parse tree produced by `EasyParser.boolean_expression`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitBoolean_expression?: (ctx: Boolean_expressionContext) => Result;

	/**
	 * Visit a parse tree produced by `EasyParser.pred`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitPred?: (ctx: PredContext) => Result;

	/**
	 * Visit a parse tree produced by `EasyParser.comparison_operator`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitComparison_operator?: (ctx: Comparison_operatorContext) => Result;

	/**
	 * Visit a parse tree produced by `EasyParser.match_operator`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitMatch_operator?: (ctx: Match_operatorContext) => Result;

	/**
	 * Visit a parse tree produced by `EasyParser.expression_list_`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitExpression_list_?: (ctx: Expression_list_Context) => Result;

	/**
	 * Visit a parse tree produced by `EasyParser.expression`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitExpression?: (ctx: ExpressionContext) => Result;

	/**
	 * Visit a parse tree produced by `EasyParser.aggr_expression`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitAggr_expression?: (ctx: Aggr_expressionContext) => Result;

	/**
	 * Visit a parse tree produced by `EasyParser.primitive_expression`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitPrimitive_expression?: (ctx: Primitive_expressionContext) => Result;

	/**
	 * Visit a parse tree produced by `EasyParser.time_span`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitTime_span?: (ctx: Time_spanContext) => Result;

	/**
	 * Visit a parse tree produced by `EasyParser.time_interval`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitTime_interval?: (ctx: Time_intervalContext) => Result;

	/**
	 * Visit a parse tree produced by `EasyParser.literal`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitLiteral?: (ctx: LiteralContext) => Result;

	/**
	 * Visit a parse tree produced by `EasyParser.int_number`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitInt_number?: (ctx: Int_numberContext) => Result;

	/**
	 * Visit a parse tree produced by `EasyParser.number`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitNumber?: (ctx: NumberContext) => Result;

	/**
	 * Visit a parse tree produced by `EasyParser.table_name`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitTable_name?: (ctx: Table_nameContext) => Result;

	/**
	 * Visit a parse tree produced by `EasyParser.column_alias`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitColumn_alias?: (ctx: Column_aliasContext) => Result;

	/**
	 * Visit a parse tree produced by `EasyParser.column`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitColumn?: (ctx: ColumnContext) => Result;

	/**
	 * Visit a parse tree produced by `EasyParser.string`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitString?: (ctx: StringContext) => Result;

	/**
	 * Visit a parse tree produced by `EasyParser.id_`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitId_?: (ctx: Id_Context) => Result;
}

