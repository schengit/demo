import { CandidateRule, CandidatesCollection } from "antlr4-c3";
import { EasyParser } from "./generated/EasyParser";
import { CommonTokenStream } from "antlr4ts";
import { ParseTree } from "antlr4ts/tree/ParseTree";

export type Configuration = {
  IgnoredTokens: Set<number>;
  SkippedTokens: Set<number>;
  TokenSuggestionResolver: Map<number, (token: number, tokenList: number[], context: SuggestionContext, config: Configuration) => Promise<Suggestion[]>>;
  RuleSuggestionResolver: Map<number, (ruleCode: number, rule: CandidateRule, context: SuggestionContext, config: Configuration) => Promise<Suggestion[]>>;

/**
   * Function that retrieves the list of tables.
   * 
   * @param table name of the table to gather the list of columns for
   * @returns list of table name
   */
  TablesResolver?: () => Promise<Array<Suggestion & {type: 'table'}>>;

  /**
   * Function that retrieves the list of columns for the given table.
   * 
   * @param table name of the table to gather the list of columns for
   * @returns list of columns for the given table
   */
  ColumnsResolver?: (table: string) => Promise<Array<Suggestion & {type: 'identifier'}>>;

  /**
   * Function that fetches and build the list of values for the given column and returns a list of Suggestion
   * objects.
   * 
   * @param column name of the column suggesting values for.
   * @returns list of values available for this column (usually of types string, number, boolean).
   */
  ValuesResolver?: (column: string, table: string) => Promise<Array<Suggestion & {type: 'string' | 'number' | 'boolean'}>>;
};

export type CaretPosition = { line: number; column: number };
export type TokenPosition = { index: number; context: ParseTree; text: string };

export type SuggestionContext = {
  tokens: CommonTokenStream;
  parser: EasyParser;
  candidates: CandidatesCollection;
  textToMatch: string;
  tokenIndex?: number;
  textStart?: number;
  textStop?: number;
};

export type SuggestionType = 'table' | 'operator' | 'keyword' | 'function' | 'timeunit' | 'boolean' | 'symbol' | 'string' | 'number' | 'identifier' | 'comment' | 'any' | 'error';

export type Suggestion = {
  value: string;
  type: SuggestionType;
  position?: {
    start?: number;
    stop?: number;
  };
};

export const tokenTypeMapping = new Map<number, SuggestionType>([
  [EasyParser.EVENTLOG, 'table'],

  [EasyParser.AVG, 'function'],
  [EasyParser.COUNT, 'function'],
  [EasyParser.MAX, 'function'],
  [EasyParser.MIN, 'function'],
  [EasyParser.SUM, 'function'],
 
  [EasyParser.SECOND_, 'timeunit'],
  [EasyParser.MINUTE_, 'timeunit'],
  [EasyParser.HOUR_, 'timeunit'],
  [EasyParser.DAY_, 'timeunit'],
  [EasyParser.WEEK_, 'timeunit'],
  [EasyParser.MONTH_, 'timeunit'],
  [EasyParser.YEAR_, 'timeunit'],

  [EasyParser.FALSE, 'boolean'],
  [EasyParser.TRUE, 'boolean'],

  [EasyParser.NOT, 'keyword'],
  [EasyParser.IN, 'keyword'],
  [EasyParser.ALL, 'keyword'],
  [EasyParser.OR, 'keyword'],
  [EasyParser.AND, 'keyword'],
  [EasyParser.BETWEEN, 'keyword'],
  [EasyParser.CONTAINS, 'keyword'],
  [EasyParser.DISTINCT, 'keyword'],
  [EasyParser.STARTSWITH, 'keyword'],
  [EasyParser.ENDSWITH, 'keyword'],
  [EasyParser.LIMIT, 'keyword'],
  [EasyParser.SPAN, 'keyword'],
  [EasyParser.AS, 'keyword'],
  [EasyParser.ASC, 'keyword'],
  [EasyParser.BY, 'keyword'],
  [EasyParser.DESC, 'keyword'],
  [EasyParser.TO, 'keyword'],

  [EasyParser.PIPE, 'symbol'],
  [EasyParser.EQ, 'symbol'],
  [EasyParser.LT, 'symbol'],
  [EasyParser.GT, 'symbol'],
  [EasyParser.LE, 'symbol'],
  [EasyParser.PLUS, 'symbol'],
  [EasyParser.MINUS, 'symbol'],
  [EasyParser.STAR, 'symbol'],
  [EasyParser.DIVIDE, 'symbol'],
  [EasyParser.MODULE, 'symbol'],
 
  [EasyParser.SEMI, 'symbol'],
  [EasyParser.LP, 'symbol'],
  [EasyParser.RP, 'symbol'],
  [EasyParser.DOT, 'symbol'],
  [EasyParser.COMMA, 'symbol'],
  [EasyParser.GE, 'symbol'],
  [EasyParser.NE, 'symbol'],
  [EasyParser.BOX, 'symbol'],
  [EasyParser.COLON, 'symbol'],
  [EasyParser.QM, 'symbol'],
  

  [EasyParser.SQ_STRING_LITERAL, 'string'],
  [EasyParser.DQ_STRING_LITERAL, 'string'],

  [EasyParser.INTEGRAL_LITERAL, 'number'],
  [EasyParser.FLOAT_LITERAL, 'number'],
  [EasyParser.REAL_LITERAL, 'number'],

  [EasyParser.IDENTIFIER, 'identifier'],

  [EasyParser.WS, 'any'],

  [EasyParser.LINE_COMMENT, 'comment'],
]);
