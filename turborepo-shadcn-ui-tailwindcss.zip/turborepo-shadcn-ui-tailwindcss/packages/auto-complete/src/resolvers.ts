import { CandidateRule } from "antlr4-c3";
import { Configuration, Suggestion, SuggestionContext , SuggestionType} from "./types";
import { EasyParser } from "./generated/EasyParser";
import { CommonTokenStream, Token } from "antlr4ts";

export async function emptyResolver(): Promise<Suggestion[]> {
    return [];
}

export async function tableSuggestions(ruleCode: number, rule: CandidateRule, context: SuggestionContext, config: Configuration): Promise<Suggestion[]> {
    if (config.TablesResolver) {
  
        const suggestions: Suggestion[] = await config.TablesResolver(); // [{value: 'test_table', type: 'table'}]
        return suggestions.map(s => ({ ...s, position: {start: context.textStart, stop: context.textStop}}));
    }

    return [];
}

export async function columnsSuggestions(ruleCode: number, rule: CandidateRule, context: SuggestionContext, config: Configuration): Promise<Suggestion[]> {
    if (config.ColumnsResolver) {
        //const isAJoin = rule.ruleList.indexOf(EasyParser.RULE_join_operator) > -1;
        //const isALookup = rule.ruleList.indexOf(EasyParser.RULE_lookup_operator) > -1;
        //const rightColumnRules = [ EasyParser.RULE_right_column, EasyParser.RULE_right_table_column ];

        let table = context.parser.vocabulary.getDisplayName(EasyParser.EVENTLOG)!.toLowerCase().replace(/['"]/g, '');

        const suggestions = await getColumns(table, config.ColumnsResolver)
        return suggestions.map(s => ({ ...s, position: {start: context.textStart, stop: context.textStop}}));
    }

    return [];
}

export async function valuesSuggestions(ruleCode: number, rule: CandidateRule, context: SuggestionContext, config: Configuration): Promise<Suggestion[]> {
    const defaultTable = context.parser.vocabulary.getDisplayName(EasyParser.EVENTLOG)!.toLowerCase().replace(/['"]/g, '');
    const columns = (await getColumns(defaultTable, config.ColumnsResolver)).map(c => c.value.toLowerCase());

    if (rule.ruleList.indexOf(EasyParser.RULE_pred) > -1) {
        const { token } = findToken<Token & {text: string}>(
            context.tokens,
            rule.startTokenIndex,
            (token) => token.type === EasyParser.IDENTIFIER && token.text !== undefined && columns.indexOf(token.text.toLowerCase()) > -1,
            (token) => token.type === EasyParser.PIPE,
        );

        if (token === undefined || !config.ValuesResolver) {
            return [];
        }

        const defaultTable = context.parser.vocabulary.getDisplayName(EasyParser.EVENTLOG)!.toLowerCase().replace(/['"]/g, '');
        return (await config.ValuesResolver(token.text.toLowerCase(), defaultTable)).map(s => {
            const suggestion = formatValueSuggestion(s);
            return { ...suggestion, position: {start: context.textStart, stop: context.textStop}};
        });
    }

    return [];
}

export async function stringValuesSuggestions(ruleCode: number, rule: CandidateRule, context: SuggestionContext, config: Configuration): Promise<Suggestion[]> {
    const defaultTable = context.parser.vocabulary.getDisplayName(EasyParser.EVENTLOG)!.toLowerCase().replace(/['"]/g, '');
    const columns = (await getColumns(defaultTable, config.ColumnsResolver)).map(c => c.value.toLowerCase());
    const stringComparisonOperators = [
        EasyParser.CONTAINS,
        EasyParser.STARTSWITH,
        EasyParser.ENDSWITH,
    ];

    if (rule.ruleList.indexOf(EasyParser.RULE_pred) > -1) {
        const { index: currentIndex, token: stringOperatorToken } = findToken(
            context.tokens,
            rule.startTokenIndex,
            (token) => stringComparisonOperators.includes(token.type),
            (token) => token.type === EasyParser.PIPE,
        );
        const { token: identifierToken } = findToken<Token & {text: string}>(
            context.tokens,
            currentIndex,
            (token) => token.type === EasyParser.IDENTIFIER && token.text !== undefined && columns.indexOf(token.text.toLowerCase()) > -1,
            (token) => token.type === EasyParser.PIPE,
        );

        if (stringOperatorToken === undefined || identifierToken === undefined || !config.ValuesResolver) {
            return [];
        }

        return (await config.ValuesResolver(identifierToken.text.toLowerCase(), defaultTable)).map(s => {
            const suggestion = formatValueSuggestion({...s, type: 'string'});
            return { ...suggestion, position: {start: context.textStart, stop: context.textStop}};
        });
    }

    return [{ value: '""', type: 'string' }];
}

function findToken<T extends Token>(
    haystack: CommonTokenStream,
    startAt: number,
    isNeedle: (token: Token) => boolean,
    stopIf?: (token: Token) => boolean,
): { index: number; token?: T } {
    let index = startAt;
    while (index > 0) {
        const token = haystack.getTokens()[index];
        if (token && isNeedle(token)) {
            return { index, token: token as T };
        }
        if (token && stopIf?.(token)) {
            break;
        }
        index--;
    }
    return { index: -1, token: undefined };
}

async function getColumns(table: string, resolver: Configuration['ColumnsResolver']): Promise<Suggestion[]> {
    if (!resolver) {
        return [];
    }

    return await resolver(table);
}

function formatValueSuggestion(suggestion: Suggestion): Suggestion {
    if (suggestion.type === 'string') {
        return {...suggestion, value: `"${suggestion.value}"`};
    }

    return suggestion;
}
