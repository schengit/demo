// @ts-expect-error - No types for postcss
module.exports = require('tailwind-config/postcss');