
export const add = (a: number, b: number) => a + b ;

export const log = (...args: unknown[]): void => {
    // eslint-disable-next-line no-console -- logger
    console.log("LOGGER: ", ...args);

  };

