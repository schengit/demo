import { Button } from '@ui/components/button';
//import { auth } from '@/auth';
import PageContainer from '@/components/layout/page-container';

export default async function Page() {
  //const session = await auth();
  //if (!session || !session.user) return null;
  const content = [];

  for (let i = 0; i < 100; i++) {
    content.push(
      <div key={i}>test linetest linetest linetest linetest linetest line</div>
    );
  }

  return (
    <PageContainer scrollable>
      {content}
      <Button>test dashboard</Button>;
    </PageContainer>
  );
}
