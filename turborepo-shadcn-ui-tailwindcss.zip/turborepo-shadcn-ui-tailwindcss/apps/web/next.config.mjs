/** @type {import('next').NextConfig} */
const nextConfig = {
  transpilePackages: ["ui"],
};

export default nextConfig;