// @ts-expect-error - No types for postcss
module.exports = require('@repo/tailwind-config/postcss');