'use client';

import React, { useState, useRef } from 'react';

export type EditorProps = {
  fields?: Array<Record<string, any>>;
  value?: string;
  //onEditorEvent?: (event: onEditorEventType) => void;
  disabled?: boolean;
};

function escapeMarkup(line: string) {
  const regExp = /["'&<>]/;
  const match = regExp.exec(line);
  if (!match) {
    return line;
  }
  const encodedSymbolMap: Record<string, string> = {
    '"': '&quot;',
    "'": '&#39;',
    '&': '&amp;',
    '<': '&lt;',
    '>': '&gt;'
  };
  const chars = line.split('');
  const safeChars = chars.map((char) => {
    return encodedSymbolMap[char] || char;
  });
  return safeChars.join('');
}

const getTotalLines = (size: number, line: string, options: any) => {
  if (size == 0) {
    return 1;
  }
  const p = document.createElement('span');

  let whiteSpace = 'pre';
  p.style.setProperty('white-space', whiteSpace);
  p.style.display = 'inline-block';
  if (typeof options.fontSize !== 'undefined') {
    p.style.fontSize = options.fontSize;
  }
  if (typeof options.fontFamily !== 'undefined') {
    p.style.fontFamily = options.fontFamily;
  }
  p.innerHTML = escapeMarkup(line);
  document.body.appendChild(p);
  const lineHeight = p.getBoundingClientRect().height;
  //console.log('height', lineHeight);

  p.style.width = size - 71 + 'px';
  p.style.setProperty('white-space', whiteSpace);
  p.style.setProperty('overflow-wrap', 'break-word');
  const totalHeight = p.getBoundingClientRect().height;
  //console.log('wrap height', totalHeight);
  let result = totalHeight / lineHeight;
  p.remove();
  return Math.ceil(result);
};

export default function Editor(props: EditorProps) {
  const [value, setValue] = useState(props.value || '');
  const textRef = useRef<HTMLTextAreaElement>(null);

  const placeholder = 'Enter a text...';

  const onChange = (evt: React.ChangeEvent<HTMLTextAreaElement>) => {
    const nvalue = evt.target.value;
    setValue(nvalue);
  };

  const onclick = () => {
    if (value.trim() === '') {
      //showSuggestions(value);
    }
  };

  const onClose = () => {
    //setOpenSuggestion(false);
  };

  const onInputKeydown = (evt: React.KeyboardEvent<HTMLTextAreaElement>) => {
    const key = evt.key;
    switch (key) {
      case 'Enter':
        if (evt.shiftKey) {
          if (value) break;
        }

        if (!evt.shiftKey) {
          evt.preventDefault();
          //do search
        }
        break;
      case 'ArrowUp':
        break;
      case 'ArrowDown':
        break;
      case 'Escape':
        break;
    }
  };

  const onPaste = (evt: React.ClipboardEvent<HTMLTextAreaElement>) => {
    const paste = (evt.clipboardData || window.Clipboard).getData('text');
  };

  const getLines = () => {
    let lines: string[] = [];
    if (textRef.current) {
      const editorWidth = textRef.current.getBoundingClientRect().width;
      const cStyles = window.getComputedStyle(textRef.current, null);
      const fontSize = cStyles.getPropertyValue('font-size');
      const fontFamily = cStyles.getPropertyValue('font-family');
      const lineValues = value.split('\n');
      lineValues.map((line, i) => {
        lines.push(i + 1 + '');
        const currLines = getTotalLines(editorWidth, line, {
          fontSize,
          fontFamily
        });
        //console.log('currLines:', line, currLines);
        if (currLines > 1) {
          for (let j = 1; j < currLines; j++) {
            lines.push(' ');
          }
        }
      });
    }
    return lines;
  };

  const textareaProps: React.TextareaHTMLAttributes<HTMLTextAreaElement> = {
    autoComplete: 'off',
    autoCorrect: 'off',
    spellCheck: false,
    autoCapitalize: 'off',
    placeholder,
    style: {
      //minHeight: 25,
      ...(placeholder && !value ? { WebkitTextFillColor: '#878E93' } : {})
    },
    onChange,
    onKeyDown: onInputKeydown,
    onBlur: () => {
      console.log('blur...');
    },
    onFocus: () => {
      console.log('focus...');
    },
    onClick: onclick,
    onPaste,
    value,
    readOnly: props.disabled,
    disabled: props.disabled
  };

  const lines = getLines();

  return (
    <div className="relative bottom-1 box-border min-h-7 w-full rounded-[5px] border border-solid border-gray-400 p-0 text-left">
      <textarea
        className="absolute left-0 top-0 m-0 h-full w-full resize-none overflow-hidden whitespace-pre-wrap break-words break-keep rounded border-0 bg-white px-8 py-1 text-inherit focus:border-blue-500 focus:outline-none focus:ring-2"
        {...textareaProps}
        ref={textRef}
      />
      <div className="pointer-events-none relative m-0 whitespace-pre-wrap border-0 bg-none px-8 py-1">
        <div className="absolute left-0 top-0 flex h-full w-4 flex-col items-center rounded-bl-sm rounded-tl-sm bg-slate-400 px-0 py-1 font-thin">
          {lines.map((num, i) => {
            return (
              <div key={num + i} className="">
                {num}
              </div>
            );
          })}
        </div>
        {value}
        <br />
      </div>
    </div>
  );
}
