'use client';

import React, { useState, useRef } from 'react';

export type EditorProps = {
  fields?: Array<Record<string, any>>;
  value?: string;
  //onEditorEvent?: (event: onEditorEventType) => void;
  disabled?: boolean;
};

export default function Editor(props: EditorProps) {
  const [value, setValue] = useState(props.value || '');
  const textRef = useRef<HTMLTextAreaElement>(null);

  const placeholder = 'Enter a text...';

  const onChange = (evt: React.ChangeEvent<HTMLTextAreaElement>) => {
    const nvalue = evt.target.value;
    setValue(nvalue);
  };

  const onclick = () => {
    if (value.trim() === '') {
      //showSuggestions(value);
    }
  };

  const onClose = () => {
    //setOpenSuggestion(false);
  };

  const onInputKeydown = (evt: React.KeyboardEvent<HTMLTextAreaElement>) => {
    const key = evt.key;
    switch (key) {
      case 'Enter':
        if (evt.shiftKey) {
          if (value) break;
        }

        if (!evt.shiftKey) {
          evt.preventDefault();
          //do search
        }
        break;
      case 'ArrowUp':
        break;
      case 'ArrowDown':
        break;
      case 'Escape':
        break;
    }
  };

  const onPaste = (evt: React.ClipboardEvent<HTMLTextAreaElement>) => {
    const paste = (evt.clipboardData || window.Clipboard).getData('text');
  };

  const textareaProps: React.TextareaHTMLAttributes<HTMLTextAreaElement> = {
    autoComplete: 'off',
    autoCorrect: 'off',
    spellCheck: false,
    autoCapitalize: 'off',
    placeholder,
    style: {
      //minHeight: 25,
      ...(placeholder && !value ? { WebkitTextFillColor: '#878E93' } : {})
    },
    onChange,
    onKeyDown: onInputKeydown,
    onBlur: () => {
      console.log('blur...');
    },
    onFocus: () => {
      console.log('focus...');
    },
    onClick: onclick,
    onPaste,
    value,
    readOnly: props.disabled,
    disabled: props.disabled
  };

  const lines = getLines();

  return (
    <div className="relative bottom-1 box-border min-h-7 w-full rounded-[5px] border border-solid border-gray-400 p-0 text-left">
      <textarea
        className="absolute left-0 top-0 m-0 h-full w-full resize-none overflow-hidden whitespace-pre-wrap break-words break-keep rounded border-0 bg-white px-8 py-1 text-inherit focus:border-blue-500 focus:outline-none focus:ring-2"
        {...textareaProps}
        ref={textRef}
      />
      <div className="pointer-events-none relative m-0 whitespace-pre-wrap border-0 bg-none px-8 py-1">
        <div className="line-box">
          {lines.map((num, i) => {
            return (
              <div key={num + i} className="line">
                {num}
              </div>
            );
          })}
        </div>
        {value}
        <br />
      </div>
    </div>
  );
}
